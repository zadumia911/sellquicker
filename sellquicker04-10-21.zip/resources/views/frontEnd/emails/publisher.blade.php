<h3>You have a new massage from your www.hatbodol.com</h3>
 <p><b>Name :</b> {{$cname}}</p>
 <p><b>Phone :</b> {{$cphone}}</p>
 <p><b>Sent Via :</b>{{$cemail}}</p>
 <p><b>Visitor Says :</b>{{$ctext}}</p>