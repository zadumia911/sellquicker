<h3>You have a new massage from your www.hatbodol.com</h3>
 <p><b>Name :</b> {{$visitor_name}}</p>
 <p><b>Phone :</b> {{$visitor_phone}}</p>
 <p><b>Sent Via :</b>{{$visitor_email}}</p>
 <p><b>Visitor Says :</b>{{$visitor_message}}</p>