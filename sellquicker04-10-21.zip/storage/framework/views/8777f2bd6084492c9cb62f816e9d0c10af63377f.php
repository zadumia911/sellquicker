<div class="customer-sidebar">
    <div class="customer-info">
        <div class="title">
            <p>Customer Panel</p>
        </div>
        <?php
             $customerId = Session::get('customerId');
             $customerInfo=App\Customer::where(['id'=>$customerId])->first();
         ?>
        <div class="image">
           <img src="<?php echo e(asset($customerInfo->image)); ?>" alt="">
        </div>
        <div class="name">
            <p><?php echo e($customerInfo->name); ?></p>
        </div>
    </div>
    <!-- customer info end -->
    <div class="customer-menu">
        <ul>
            <li class="<?php echo e(Request::is('customer/0/control-panel/dashboard') ? 'active':''); ?>"><a href="<?php echo e(url('customer/0/control-panel/dashboard')); ?>"><i class="fe fe-home"></i>My Dashboard</a></li>

            <li class="<?php echo e(Request::is('customer/'.$customerInfo->slug.'/0/control-panel/'.$customerInfo->id.'/edit') ? 'active':''); ?>"><a href="<?php echo e(url('customer/'.$customerInfo->slug.'/0/control-panel/'.$customerInfo->id.'/edit')); ?>"><i class="fe fe-user"></i> Edit Profile</a></li>

            <li class="<?php echo e(Request::is('customer/0/control-panel/manage-my-ads') ? 'active':''); ?>"><a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>"><i class="fe fe-target"></i> Manage Ads </a></li>

            <li class="<?php echo e(Request::is('customer/'.$customerInfo->slug.'/0/control-panel/'.$customerInfo->id.'/post-new-ads') ? 'active':''); ?>"><a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>"><i class="fe fe-rocket"></i> New Ads </a></li>

            <li><a href="<?php echo e(url('customer/0/control-panel/membership-request')); ?>"><i class="fe fe-gear"></i> Membership</a></li>
            <li><a href="<?php echo e(url('customer/logout')); ?>"><i class="fe fe-logout"></i>Logout</a></li>
        </ul>
    </div>
</div><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/frontEnd/customer/sidebar.blade.php ENDPATH**/ ?>