<?php $__env->startSection('title','Super Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/websolut/public_html/hatbodol/resources/views/backEnd/superadmin/dashboard.blade.php ENDPATH**/ ?>