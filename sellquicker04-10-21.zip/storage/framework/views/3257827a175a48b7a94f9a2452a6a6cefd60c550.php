
<?php $__env->startSection('title','Forget Password Reset'); ?>
<?php $__env->startSection('content'); ?>
<section class="breadcrumb-area" style="background: url(<?php echo e(asset('public/frontEnd/images/customer-login.jpg')); ?>)">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-12">
        <div class="breadcrumb-content">
          <h3>Forget Password Reset</h3>
          <ul>
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a class="anchor"><i class="fa fa-angle-right"></i></a></li>
            <li><a class="anchor">Forget Password Reset</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="section-padding commonpanel">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0"></div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="commonpanelform">
          <h5 class="title">Forget Password Reset</h5>
				<form action="<?php echo e(url('customer/forget-password/reset')); ?>" method="POST">
					<?php echo csrf_field(); ?>
					  <div class="form-group">
						<label for="verifycode">Verify Code</label>
						<input type="text" name="verifycode" id="verifycode" class="form-control<?php echo e($errors->has('verifycode')? 'is-invalid' : ''); ?>" value="<?php echo e(old('verifycode')); ?>">
						<?php if($errors->has('verifycode')): ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('verifycode')); ?></strong>
                            </span>
                        <?php endif; ?>
					</div>

					 <div class="form-group">
						<label for="newpassword">New Password</label>
						<input type="password" name="newpassword" id="newpassword" class="form-control<?php echo e($errors->has('newpassword')? 'is-invalid' : ''); ?>" value="<?php echo e(old('newpassword')); ?>">
						<?php if($errors->has('newpassword')): ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('newpassword')); ?></strong>
                            </span>
                        <?php endif; ?>
					</div>
					<div class="form-group">
						<button>Submit</button>
					</div>
				</form>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3"></div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/customer/passwordreset.blade.php ENDPATH**/ ?>