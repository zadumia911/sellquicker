<?php $__env->startSection('title','Post New Ads'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>Post New Ads</p>
                    </div>
                    <div class="cbmain-content">
                        <form action="<?php echo e(url('/customer/0/control-panel/post-new-ads')); ?>" method="POST" novalidate enctype="multipart/form-data">
                        	<?php echo csrf_field(); ?>
                        	<input type="hidden" value="<?php echo e($customerId = Session::get('customerId')); ?>" name="customer">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="category">Category <span>*</span></label>
                                      <select  name="category" id="category" class="form-control<?php echo e($errors->has('category') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('category')); ?>" required>
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                         <?php if($errors->has('category')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('category')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="subcategory">Subcategory <span>*</span></label>
                                      <select  name="subcategory" class="form-control<?php echo e($errors->has('subcategory') ? ' is-invalid' : ''); ?>"  id="subcategory" required>
                                       	 <option value="">Select Subcategory</option>
                                  	   </select>
                                  	   <?php if($errors->has('subcategory')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('subcategory')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="division_id" >Divistion/Zila <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('division_id') ? ' is-invalid' : ''); ?>" name="division_id" id="division" required="required">
                                          <option value="">Division</option>
                                               <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			                                      	<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>

  			                                      	</option>
			                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                               <?php if($errors->has('division_id')): ?>
			                                    <span class="invalid-feedback" role="alert">
			                                      <strong><?php echo e($errors->first('division_id')); ?></strong>
			                                    </span>
			                                    <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="dist_id" >District <span>*</span></label>
                                     <div class="form-group">
                                      <select class="form-control" name="dist_id" id="district" required="required">
                                      	<option value="">District</option>
                                 	  </select>
                                 	   <?php if($errors->has('dist_id')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('dist_id')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                 </div>
                                 <!--form-group end-->
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="thana_id" >Thana <span>*</span></label>
                                     <div class="form-group">
                                      <select class="form-control" name="thana_id" id="thana" required="required">
                                        <option value="">Thana</option>
                                    </select>
                                     <?php if($errors->has('thana_id')): ?>
                                       <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('thana_id')); ?></strong>
                                       </span>
                                      <?php endif; ?>
                                  </div>
                                 <!--form-group end-->
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="union_id" >Union/City Corporation <span>*</span></label>
                                     <div class="form-group">
                                      <select class="form-control" name="union_id" id="union" required="required">
                                        <option value="">Union</option>
                                    </select>
                                     <?php if($errors->has('union_id')): ?>
                                       <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('union_id')); ?></strong>
                                       </span>
                                      <?php endif; ?>
                                  </div>
                                 <!--form-group end-->
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-4 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="version" >Condition <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('version') ? ' is-invalid' : ''); ?>" name="version" value="<?php echo e(old('version')); ?>" id="version" required="required">
                                          <option value="">Select Condition</option>
                                               
                                                <option value="1">Used
                                                <option value="2">New
                                                </option>

                                               <?php if($errors->has('version')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('version')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="type" >Authenticity <span>(optional)</span></label>
                                      <select class="form-control<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" name="type" value="<?php echo e(old('type')); ?>" id="type">
                                          <option value="">Select Type</option>
                                                <option value="1">Original
                                                <option value="2">Copy
                                                </option>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="brand">Brand <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('brand')? 'is-invalid' : ''); ?>" id="brand" placeholder="Ads brand" name="brand" value="<?php echo e(old('brand')); ?>" required>

                                      <?php if($errors->has('brand')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('brand')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="model">Model <span>(optional)</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('model')? 'is-invalid' : ''); ?>" id="model" placeholder="Ads model" name="model" value="<?php echo e(old('model')); ?>" required>

                                      <?php if($errors->has('model')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('model')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="edition">Edition <span>(Optional)</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('edition')? 'is-invalid' : ''); ?>" id="edition" placeholder="Ads edition" name="edition" value="<?php echo e(old('edition')); ?>" required>

                                      <?php if($errors->has('edition')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('edition')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <label for="title">Ads Title <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" id="title" placeholder="Ads Title" name="title" value="<?php echo e(old('title')); ?>" required>
                                    </div>
                                     <?php if($errors->has('title')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('title')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->


                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <label for="feature">Ads Feature <span>*</span></label>
                                      <textarea id="feature" class="<?php echo e($errors->has('feature')? 'is-invalid' : ''); ?> form-control" name="feature" rows="6"><?php echo e(old('feature')); ?></textarea>
                                      <?php if($errors->has('feature')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('feature')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <label for="description">Ads Description <span>*</span></label>
                                      <textarea class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"name="description" rows="6"><?php echo e(old('description')); ?></textarea>
                                      <?php if($errors->has('description')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('description')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="phone">Phone Numbers <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" id="phone" placeholder="phone numbers" maxlength="25" name="phone" value="" required>
                                      <?php if($errors->has('phone')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('phone')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="email">Email Address <span>(optional)</span></label>
                                      <input type="text" class="form-control" id="email" placeholder="Email numbers" maxlength="25" name="email" value="">
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                      <label for="price">Price <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" id="price" placeholder="25000 Taka" maxlength="25" name="price" value="<?php echo e(old('price')); ?>" required>
                                       <?php if($errors->has('price')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('price')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                
                                <div class="col-lg-6 col-md-6 col-sm-12">
                                  <div class="form-group">
                                    <strong>Size: max:6MB, Weight:695, Height:325 ,type:jpg,jpeg,png</strong><br>
                                    <label for="image">Product Picture<span>*</span></label>

                                      <div class="clone hide" style="display: none;">
                                        <div class="control-group input-group<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" style="margin-top:10px">
                                          <input type="file" name="image[]" class="form-control">
                                          <div class="input-group-btn"> 
                                            <button class="btn btn-danger" type="button"><i class="fa fa-trash"></i></button>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="input-group control-group increment<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" >
                                        <input type="file" name="image[]" class="form-control">
                                        <div class="input-group-btn"> 
                                          <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
                                        </div>
                                      </div>
                                      <?php if($errors->has('image')): ?>
	                                     <span class="invalid-feedback" role="alert">
	                                      <strong><?php echo e($errors->first('image')); ?></strong>
	                                     </span>
	                                    <?php endif; ?>
                                  </div>
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <button class="cbutton">Upload</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/frontEnd/customer/postads.blade.php ENDPATH**/ ?>