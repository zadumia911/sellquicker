<?php $__env->startSection('title','All Membership'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Customer</a></li>
            <li class="breadcrumb-item active">All Membership</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>All Membership</h5>
              </div>
            </div>
          </div>
      </div>
        <div class="box-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Image</th>
                        <th>Membership Status</th>
                        <th>Action</th>
                        <th></th>
                      </tr>
                      </thead>
                      <tbody>
                       <?php $__currentLoopData = $allmembership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($value->name); ?></td>
                          <td><?php echo e($value->email); ?></td>
                          <td><?php echo e($value->phone); ?></td>
                          <td><img src="<?php echo e(asset($value->image)); ?>" class="backend_image" alt=""></td>
                          <td><?php echo e($value->membership==1?"Yes":"No"); ?></td>
                          <td>
                            <ul class="action_buttons dropdown">
                              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action Button
                              <span class="caret"></span></button>
                              <ul class="dropdown-menu">
                                   <li>
                                    <a href="#" class="btn btn-info" data-toggle="modal" data-target="#exampleModal<?php echo e($value->id); ?>"> View Details</a>
                                  </li>
                                  <li>
                                    <form action="<?php echo e(url('superadmin/customer/membership-accept')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="customer" value="<?php echo e($value->id); ?>">
                                      <button type="submit" onclick="return confirm('Are you sure ? Accept membership for this customer.')" class="edit_icon"><i class="fa fa-check"></i> Accept Request</button>
                                    </form>
                                  </li>
                                  <li>
                                    <form action="<?php echo e(url('superadmin/customer/membership-cancel')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="customer" value="<?php echo e($value->id); ?>">
                                      <button type="submit" onclick="return confirm('Are you sure ? Cancel membership for this customer.')" class="edit_icon"> Cancel Membership</button>
                                    </form>
                                  </li>
                                  
                                </ul>
                              </ul>
                          </td>
                         <td>
                         <!-- Modal -->
                          <?php
                            $membershopinfoes = App\Membershipform::where('customerId',$value->id)->orderBy('id','DESC')->limit(1)->get();
                          ?>
                            <div class="modal fade" id="exampleModal<?php echo e($value->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                   <table class="table table-bordered">
                                    <?php $__currentLoopData = $membershopinfoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membershopinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <tr>
                                       <td>Shop Name</td>
                                       <td><?php echo e($membershopinfo->shopname); ?></td>
                                     </tr>
                                     <tr>
                                       <td>Shop Holder Name</td>
                                       <td><?php echo e($membershopinfo->shopholdername); ?></td>
                                     </tr>
                                     <tr>
                                       <td>Shop Holder Phone</td>
                                       <td><?php echo e($membershopinfo->shopholderphone); ?></td>
                                     </tr>
                                     <tr>
                                       <td>Shop Address</td>
                                       <td><?php echo e($membershopinfo->shopaddress); ?></td>
                                     </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </table>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- modal end -->
                         </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tfoot>
                    </table>
                    <!-- Button trigger modal -->


                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
          </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/backEnd/customer/allmembership.blade.php ENDPATH**/ ?>