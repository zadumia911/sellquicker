<?php $__env->startSection('title','Manage New Ads Request'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">New Ads Request</a></li>
            <li class="breadcrumb-item active">Manage</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Manage New Ads Request</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/all-ads/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                All Ads <i class="fas fa-plus"></i>
                </a>
              </div>
            </div>
          </div>
      </div>
        <div class="box-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $newadsrequest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($value->title); ?> </td>
                          <td>
                             <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					            <?php if($value->id==$image->ads_id): ?>
					               <img src="<?php echo e(asset($image->image)); ?>" class="backend_image" alt="">
					                <?php break; ?>
					            <?php endif; ?>
					        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                          <td><?php echo e($value->catname); ?> <i class="fas fa-angle-right"></i> <?php echo e($value->subcategoryName); ?>

                          </td>
                          <td> <button data-toggle="modal" class="btn btn-info btn-sm" data-target="#myModal<?php echo e($value->id); ?>"><?php echo e($value->customername); ?></button>
                          
                          <!-- Modal -->
                                <div id="myModal<?php echo e($value->id); ?>" class="modal fade" role="dialog">
                                  <div class="modal-dialog">
                                    <!-- Modal content-->
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h4 class="modal-title">Customer Basic Information</h4>
                                        
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                                      <div class="modal-body">
                                        <p><img src="<?php echo e(asset($value->customerimage)); ?>" class="backend_image"></p>
                                        <p><?php echo e($value->customername); ?></p>
                                        <p><a href="tel:<?php echo e($value->customerphone); ?>"><?php echo e($value->customerphone); ?></a></p>
                                        <p><a href="mailto:<?php echo e($value->customeremail); ?>"><?php echo e($value->customeremail); ?></a></p>
                                      </div>
                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                      </div>
                                    </div>
                                
                                  </div>
                                </div>
                          </td>
                          <td><?php echo e($value->status==1?"Active":"Inactive"); ?></td>
                          <td>
                          	<ul class="action_buttons dropdown">
                              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action Button
                              <span class="caret"></span></button>
                              <ul class="dropdown-menu">
                              	<li>
                              		<a class="edit_icon" href="<?php echo e(url('admin/customer/ads/activation/'.$value->id)); ?>" title="Edit"><i class="fas fa-check"></i> Activation</a>
                              	</li>
                                <li>
                                  <?php if($value->status==1): ?>
                                  <form action="<?php echo e(url('admin/customer/ads/unpublished')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                    <button type="submit" onclick="return confirm('Are you continue this this?')" class="thumbs_up" title="unpublished"><i class="fa fa-thumbs-up"></i> Published</button>
                                  </form>
                                  <?php else: ?>
                                    <form action="<?php echo e(url('admin/customer/ads/published')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                      <button type="submit" onclick="return confirm('Are you continue this this?')" class="thumbs_down" title="published"><i class="fa fa-thumbs-down"></i> Unpublished</button>
                                    </form>
                                  <?php endif; ?>
                                </li>
                                 <li>
                                    <form action="<?php echo e(url('admin/customer/ads/delete')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                      <button type="submit" onclick="return confirm('Are you delete this this?')" class="trash_icon" title="Delete"><i class="fa fa-trash"></i> Delete</button>
                                    </form>
                                  </li>
                                </ul>
                              </ul>
                          </td>
                          <!-- customer details -->
                          <div id="myModal<?php echo e($value->customerId); ?>" class="modal fade" role="dialog">
	                        <div class="modal-dialog">
	                          <!-- Modal content-->
	                          <div class="modal-content">
	                            <div class="modal-header">
	                                  <button type="button" class="close" data-dismiss="modal">&times;</button>
	                            </div>
	                            <div class="modal-body">

	                              <div class="profileimage">
	                                <img src="<?php echo e(asset($value->customerimage)); ?>" alt="">
	                              </div>
	                              <p><strong>Customar Name : </strong> <?php echo e($value->customername); ?></p>
	                              <p><strong>Customar Email :</strong> <?php echo e($value->email); ?></p>
	                              <p><strong>Customar Phone :</strong> <?php echo e($value->phone); ?></p>
	                            </div>
	                            <div class="modal-footer">
	                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	                            </div>
	                          </div>

	                        </div>
	                      </div>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tfoot>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
          </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/backEnd/adsmanage/requestads.blade.php ENDPATH**/ ?>