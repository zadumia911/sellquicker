<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
<section id="banner">
      <div class="container">
          <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                  <div class="hsearch-box">
                      <form action="<?php echo e(url('search/products')); ?>" method="POST">
                      	<?php echo csrf_field(); ?>
                          <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12">
                                 <div class="form-group <?php echo e($errors->has('category') ? ' is-invalid' : ''); ?>">
                                      <select  name="category" id="category">
	                                      <option value="">Select Category</option>
	                                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                      	<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
	                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	                                      <?php if($errors->has('category')): ?>
		                                    <span class="invalid-feedback" role="alert">
		                                      <strong><?php echo e($errors->first('category')); ?></strong>
		                                    </span>
		                                    <?php endif; ?>
                                 	   </select>
                                 </div>
                                 <!--form-group end-->
                                 <div class="clearfix"></div>
                            </div>
                            
                             <div class="col-lg-3 col-md-3 col-sm-12">
                                 <div class="form-group">
                                      <select  name="subcategory" id="subcategory">
                                       	 <option value="">Select Subcategory</option>
                                  	   </select>
                                 </div>
                                 <!--form-group end-->
                             </div>
                             <div class="col-lg-2 col-md-2 col-sm-12">
                                 <div class="form-group">
                                      <select class="<?php echo e($errors->has('area') ? ' is-invalid' : ''); ?>" name="area" id="area">
                                          <option value="">Location</option>
                                               <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                      	<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>

			                                      	</option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                               <?php if($errors->has('area')): ?>
			                                    <span class="invalid-feedback" role="alert">
			                                      <strong><?php echo e($errors->first('area')); ?></strong>
			                                    </span>
			                                    <?php endif; ?>
                                      </select>
                                    
                                 </div>
                                 <!--form-group end-->
                             </div>
                             <div class="col-lg-2 col-md-2 col-sm-12">
                                 <div class="form-group">
                                      <select class="bordertransparent" name="subarea" id="subarea">
                                      	<option value="">Sub Area</option>
                                 	  </select>
                                 </div>
                                 <!--form-group end-->
                             </div>
                             <div class="col-lg-2 col-md-2 col-sm-12">
                                 <div class="form-group">
                                      <button>Search</button>
                                 </div>
                               <!--form-group end-->
                             </div>
                         </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
 </section>
<!--banner section end-->
<section class="category-section">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-7 col-sm-12">
				<div class="category-inner">
					<div class="row">
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-6 col-sm-6">
							<div class="single-category">
								<ul>
									<li><i class="icon <?php echo e($category->icon); ?>"></i></li>
									<li><a href="<?php echo e(url('category/'.$category->slug.'/'.$category->id)); ?>"><?php echo e($category->name); ?> <?php
			                          $totalAdvertisment=App\Advertisment::where(['category_id'=>$category->id,'status'=>1])->get();
			                        ?> (<?php echo e($totalAdvertisment->count()); ?>)</a></li>
									<li class="plus"><a data-toggle="modal" data-target="#categorym<?php echo e($category->id); ?>"><i class="fe fe-plus"></i></a></li>
								</ul>
								<!-- Trigger the modal with a button -->
								<!-- Modal -->
								<div id="categorym<?php echo e($category->id); ?>" class="categorym modal fade" role="dialog">
								  <div class="modal-dialog">

								    <!-- Modal content-->
								    <div class="modal-content">
								      <div class="modal-header">

								        <h5 class="modal-title"><a href="<?php echo e(url('category/'.$category->slug.'/'.$category->id)); ?>"><?php echo e($category->name); ?></a></h5>
								        <button type="button" class="close" data-dismiss="modal">&times;</button>
								      </div>
								      <div class="modal-body">
								        <ul>
								        	 <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        	<li><a href="<?php echo e(url('ads/'.$category->slug.'/'.$subcategory->id)); ?>"><?php echo e($subcategory->subcategoryName); ?></a></li>
								        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								        </ul>
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								      </div>
								    </div>

								  </div>
								</div>
							</div>
						</div>
						<!-- single category end -->
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<!-- col end -->
			<div class="col-lg-3 col-md-5 col-sm-12">
				<div class="catad">
					<a href="">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/catad.jpg" alt="">
					</a>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<div class="browse-all">
					<a href="<?php echo e(url('allcategory')); ?>">browse all</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- category section end -->
<section class="advertisment">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-7 col-sm-12">
				<div class="ad-inner">
					<div class="row">
						<?php $__currentLoopData = $membershipads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-6 col-sm-6">
								<div class="single-ads">
									<div class="ads-image">
										<a href="<?php echo e(url('details/'.$value->id)); ?>">
											 <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                             <?php if($value->id==$image->ads_id): ?>
					                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
					                              <?php break; ?>
					                              <?php endif; ?>
					                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</a>
									</div>
									<div class="ads-content">
										<ul class="catandloc">
											<li class="cat"><a href=""><i class="fa fa-circle-o"></i><?php echo e($value->catname); ?></a></li>
											<li class="loc"><a href=""><i class="fa fa-map-marker"></i><?php echo e($value->subareaName); ?></a></li>
										</ul>
										<div class="title">
											<a href="<?php echo e(url('details/'.$value->id)); ?>"><?php echo e(substr($value->title,0,30)); ?>..</a>
										</div>
										<ul class="price-wishlist">
											<li class="price"><?php echo e($value->price); ?></li>
											<?php if($value->membership): ?>
											<li class="wishlist"><a href="wishlist">Premium</a></li>
											<?php endif; ?>
										</ul>
									</div>
								</div>
							</div>
							<!-- single ads end -->
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php $__empty_1 = true; $__currentLoopData = $advertisments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<div class="col-lg-4 col-md-6 col-sm-6">
								<div class="single-ads">
									<div class="ads-image">
										<a href="<?php echo e(url('details/'.$value->id)); ?>">
											 <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                             <?php if($value->id==$image->ads_id): ?>
					                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
					                              <?php break; ?>
					                              <?php endif; ?>
					                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</a>
									</div>
									<div class="ads-content">
										<ul class="catandloc">
											<li class="cat"><a href=""><i class="fa fa-circle-o"></i><?php echo e($value->catname); ?></a></li>
											<li class="loc"><a href=""><i class="fa fa-map-marker"></i><?php echo e($value->subareaName); ?></a></li>
										</ul>
										<div class="title">
											<a href="<?php echo e(url('details/'.$value->id)); ?>"><?php echo e(substr($value->title,0,30)); ?>..</a>
										</div>
										<ul class="price-wishlist">
											<li class="price"><?php echo e($value->price); ?></li>
											<?php if($value->membership): ?>
											<li class="wishlist"><a href="wishlist">Premium</a></li>
											<?php endif; ?>
										</ul>
									</div>
								</div>
							</div>
							<!-- single ads end -->
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			            <p>No Data Available</p>
			            <?php endif; ?>
					</div>
				</div>
			</div>
			<!-- first col-9 end -->
			<div class="col-lg-3 col-md-5 col-sm-12">
				<div class="mads">
					<a href="">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/hproad1.jpg" alt="">
					</a>
				</div>
				<!-- mads end -->
				<div class="locationad-inner">
					<div id="location-ads" class="location-ads ">
						<ul>
							<?php $__currentLoopData = $subareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('/location/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->subareaName); ?> <span> <?php $totalsubarea = App\Advertisment::where('subarea_id',$value->id)->get(); ?> (<?php echo e($totalsubarea->count()); ?>)</span></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						
				    </div>
					<!-- <button type="button" id="addDiv" class="addDiv"><i class="fa fa-plus"></i> Show All</button>
					<button type="button" id="removeDiv" class="removeDiv"><i class="fa fa-minus"></i> Less</button> -->
				</div>
			</div>
			<!-- first col-3 -->
		</div>
		<!-- row end -->
	</div>
</section>
<!-- advertisment end -->
<section id="counter">
	<div class="container">
			<div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">350</h4>
                        <h5>Total Account</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">540</h4>
                        <h5>Total Advertisment</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">105</h4>
                        <h5>Total Member</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">25</h4>
                        <h5>Current Visitor</h5>
                    </div>
                </div>
                <!--col end-->
            </div>
            <!--row end-->
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/frontEnd/index.blade.php ENDPATH**/ ?>