<?php $__env->startSection('title','Post New Ads'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-9">
                <div class="customer-body">
                    <div class="title">
                        <p>Post New Ads</p>
                    </div>
                    <div class="cbmain-content">
                        <form action="<?php echo e(url('/customer/0/control-panel/post-new-ads')); ?>" method="POST" novalidate enctype="multipart/form-data">
                        	<?php echo csrf_field(); ?>
                        	<input type="hidden" value="<?php echo e($customerId = Session::get('customerId')); ?>" name="customer">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="category">Category <span>*</span></label>
                                      <select  name="category" id="category" class="form-control" required>
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="subcategory">Subcategory <span>*</span></label>
                                      <select  name="subcategory" class="form-control" id="subcategory" required>
                                       	 <option value="">Select Subcategory</option>
                                  	   </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="area" >Divistion/Zila <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('area') ? ' is-invalid' : ''); ?>" name="area" id="area" required="required">
                                          <option value="">Location</option>
                                               <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  			                                      	<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>

  			                                      	</option>
			                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                               <?php if($errors->has('area')): ?>
			                                    <span class="invalid-feedback" role="alert">
			                                      <strong><?php echo e($errors->first('area')); ?></strong>
			                                    </span>
			                                    <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="subarea" >Thana/Zila <span>*</span></label>
                                     <div class="form-group">
                                      <select class="form-control" name="subarea" id="subarea" required="required">
                                      	<option value="">Sub Area</option>
                                 	  </select>
                                 </div>
                                 <!--form-group end-->
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="version" >Version <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('version') ? ' is-invalid' : ''); ?>" name="version" id="version" required="required">
                                          <option value="">Select Version</option>
                                               
                                                <option value="Used">Used
                                                <option value="New">New
                                                </option>

                                               <?php if($errors->has('version')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('version')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="type" >Type <span>(optional)</span></label>
                                      <select class="form-control<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" name="type" id="type">
                                          <option value="">Select Type</option>
                                                <option value="Original">Original
                                                <option value="Copy">Copy
                                                </option>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <label for="title">Ads Title <span>*</span></label>
                                      <input type="text" class="form-control" id="title" placeholder="Ads Title" name="title" value="" required>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group custom-textarea">
                                      <label for="description">Ads Description <span>*</span></label>
                                      <textarea id="description" name="description"></textarea>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="phone">Phone Numbers <span>*</span></label>
                                      <input type="text" class="form-control" id="phone" placeholder="phone numbers" maxlength="25" name="phone" value="" required>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="email">Email Address <span>(optional)</span></label>
                                      <input type="text" class="form-control" id="email" placeholder="Email numbers" maxlength="25" name="email" value="">
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="price">Price <span>*</span></label>
                                      <input type="text" class="form-control" id="price" placeholder="25000" maxlength="25" name="price" value="" required>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                  <div class="form-group">
                                    <label for="image">Product Picture<span>*</span></label>

                                      <div class="clone hide" style="display: none;">
                                        <div class="control-group input-group" style="margin-top:10px">
                                          <input type="file" name="image[]" class="form-control">
                                          <div class="input-group-btn"> 
                                            <button class="btn btn-danger" type="button"><i class="fa fa-trash"></i></button>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="input-group control-group increment" >
                                        <input type="file" name="image[]" class="form-control">
                                        <div class="input-group-btn"> 
                                          <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
                                        </div>
                                      </div>
                                  </div>
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <button class="cbutton">Upload</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazar\resources\views/frontEnd/customer/postads.blade.php ENDPATH**/ ?>