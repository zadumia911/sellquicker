<?php $__env->startSection('title','Location'); ?>
<?php $__env->startSection('content'); ?>
<section class="advertisment">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12">
				<?php echo $__env->make('frontEnd.layouts.pages.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="mads">
					<a href="">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/hproad1.jpg" alt="">
					</a>
				</div>
				<!-- mads end -->
			</div>
			<!-- first col-3 -->
			<div class="col-lg-9 col-md-9 col-sm-12">
				<div class="ad-inner">
					<div class="ad-filter">
						<div class="row">
							<div class="col-lg-6 col-sm-6 col-sm-12">
								<h6><ul>
									<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
									<li><a class="anchor"><i class="fa fa-angle-right"></i></a></li>
									<li><a class="anchor">Search Products</a></li>
								</ul></h6>
								<p><?php echo e($advertisments->count()); ?> advertisment find</p>
							</div>
							<!-- col end -->
							<div class="col-lg-6 col-sm-6 col-sm-12">
								<div class="sort-form">
									<form action="">
										<div class="from-group">
											<select name="adsort" id="">
												<option value="1">Newest on top</option>
												<option value="2">Oldest on top</option>
												<option value="3">High to Low</option>
												<option value="3">Low to High</option>
											</select>
										</div>
									</form>
								</div>
								<div class="grid-list">
									<ul class="nav nav-tabs" id="sortTab" role="tablist">
										  <li class="nav-item">
										    <a class="nav-link active" id="gridad-tab" data-toggle="tab" href="#gridad" role="tab" aria-controls="gridad" aria-selected="true"><i class="fa fa-th"></i></a>
										  </li>
										  <li class="nav-item">
										    <a class="nav-link" id="listad-tab" data-toggle="tab" href="#listad" role="tab" aria-controls="listad" aria-selected="false"><i class="fa fa-list"></i></a>
										  </li>
								   </ul>
								</div>
							</div>
							<!-- col end -->
						</div>
					</div>
					<div  class="tab-content" id="myTabContent">
						<div  class="tab-pane fade active show " id="gridad" role="tabpanel" aria-labelledby="gridad-tab">
							<div class="row">
								<?php $__currentLoopData = $advertisments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-4 col-md-4 col-sm-6">
									<div class="single-ads">
										<div class="ads-image">
											<a href="<?php echo e(url('details/'.$value->id)); ?>">
												<?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                             <?php if($value->id==$image->ads_id): ?>
					                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
					                              <?php break; ?>
					                              <?php endif; ?>
					                         	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</a>
										</div>
										<div class="ads-content">
											<ul class="catandloc">
												<li class="cat"><a href=""><i class="fa fa-circle-o"></i><?php echo e($value->catname); ?></a></li>
												<li class="loc"><a href=""><i class="fa fa-map-marker"></i><?php echo e($value->subareaName); ?></a></li>
											</ul>
											<div class="title">
												<a href="<?php echo e(url('details/'.$value->id)); ?>"><?php echo e(substr($value->title,0,50)); ?>..</a>
											</div>
											<ul class="price-wishlist">
												<li class="price"><?php echo e($value->price); ?></li>
												<!-- <li class="wishlist"><a href="wishlist"><i class="fa fa-heart-o"></i></a></li> -->
											</ul>
										</div>
									</div>
								</div>
								<!-- single ads end -->
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						<!-- tab one -->
						  <div class="tab-pane fade" id="listad" role="tabpanel" aria-labelledby="listad-tab">
						  	<?php $__currentLoopData = $advertisments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						  	<div class="list-product">
						  		<div class="row">
							  		<div class="col-lg-4 col-md-4 col-sm-6">
							  			<div class="list-ad-image">
							  				<a href="<?php echo e(url('details/'.$value->id)); ?>">
							  					<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/ads1.jpg" alt="">
							  				</a>
							  			</div>
							  		</div>
							  		<div class="col-lg-4 col-md-4 col-sm-6">
							  			<div class="list-ad-info">
							  				<p><i class="fa fa-circle-o"></i> Home & Live</p>
							  				<p><i class="fa fa-map-marker"></i> Saidpur</p>
							  				<h5><a href="<?php echo e(url('details/'.$value->id)); ?>">Appartment In Rangpur Sell..</a></h5>
							  				<p>Full fresh car.ac ok, door auto,1500 cc engine unstalled.paper fail</p>
							  				<strong>20000 BTD</strong>
							  				<a href="wishlist.html" class="wishlist"><i class="fa fa-heart-o"></i> save</a>
							  			</div>
							  		</div>
							  		<div class="col-lg-4 col-md-4 col-sm-6">
							  			<div class="view-details">
							  				<a href="<?php echo e(url('details/'.$value->id)); ?>">view details</a>
							  			</div>
							  		</div>
							  	</div>
						  	</div>
						  	<!-- list product end -->
						  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </div>
					</div>
				</div>
				<div class="cpaginate">
					<?php echo e($advertisments->links()); ?>

				</div>
			</div>
			<!-- first col-9 end -->
		</div>
		<!-- row end -->
	</div>
</section>
<!-- advertisment end -->
<section id="counter">
	<div class="container">
			<div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">350</h4>
                        <h5>Total Account</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">540</h4>
                        <h5>Total Advertisment</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">105</h4>
                        <h5>Total Member</h5>
                    </div>
                </div>
                <!--col end-->
                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="counter-item">
                        <h4 class="counter">25</h4>
                        <h5>Current Visitor</h5>
                    </div>
                </div>
                <!--col end-->
            </div>
            <!--row end-->
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/frontEnd/layouts/pages/locationproduct.blade.php ENDPATH**/ ?>