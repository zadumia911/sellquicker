<?php $__env->startSection('title','Request For Membership'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>Request For Membership</p>
                    </div>
                    <div class="cbmain-content">
                      <?php
                       $customerId=Session::get('customerId');
                        $customerInfo=App\Customer::where(['id'=>$customerId])->first();
                       ?>
                       <?php if($customerInfo->membership == 0): ?>
                        <form action="<?php echo e(url('/customer/0/control-panel/membership-request')); ?>" method="POST" novalidate enctype="multipart/form-data" name="editForm">
                        	<?php echo csrf_field(); ?>
                        	<input type="hidden" value="<?php echo e($customerId = Session::get('customerId')); ?>" name="customer">
                              
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                  <div class="alert alert-warning alert-dismissable">
                                      <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                                      <strong>You have no membership</strong>
                                  </div>
                                  <div class="nomembership">
                                    <strong> Dear <?php echo e($customerInfo->name); ?> ! you want to receive membership ? Please click the "membership" button</strong>

                                    <h6>Membership information <a href="http://localhost/kbazarup/pages/membership/2" target="_blank" class="btn btn-info btn-sm">More Info</a></h6>

                                  </div>
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <button class="btn btn-primary btn-md">Request Membership</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php elseif($customerInfo->membership == 3): ?>
                        <div class="alert alert-info alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <strong>Dear <?php echo e($customerInfo->name); ?> ! You request for membership. Please wait for your admin aproval.</strong>
                        </div>
                        <?php elseif($customerInfo->membership == 1): ?>
                        <div class="cbmain-content">
                        <div class="alert alert-success alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <strong>Dear <?php echo e($customerInfo->name); ?> ! You Already Member.</strong>
                        </div>
                        <form action="<?php echo e(url('/customer/0/control-panel/membership-cancel')); ?>" method="POST" novalidate enctype="multipart/form-data" name="editForm">
                              <?php echo csrf_field(); ?>
                              <input type="hidden" value="<?php echo e($customerId = Session::get('customerId')); ?>" name="customer">
                                  
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                      <div class="nomembership">
                                        <strong> Dear <?php echo e($customerInfo->name); ?> ! you want to cancel membership ? Please click the "cancel membership" button</strong>

                                      </div>
                                    </div>
                                    <!-- col end -->
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <div class="form-group">
                                          <button class="btn btn-primary btn-md">Cancel Membership</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>

                        <?php elseif($customerInfo->membership == 2): ?>
                         <div class="alert alert-danger alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <strong>Dear <?php echo e($customerInfo->name); ?> ! You request for cancel membership. Please wait for your admin aproval.</strong>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/frontEnd/customer/membership.blade.php ENDPATH**/ ?>