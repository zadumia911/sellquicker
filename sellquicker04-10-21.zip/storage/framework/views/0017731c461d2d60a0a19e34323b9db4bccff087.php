<?php $__env->startSection('title','All Ad Report'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
               <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>My Ad Report</p>
                    </div>
                    <div class="cbmain-content">
                        <div class="ads-table">
                          
                          <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th scope="col">Sl No.</th>
                                  <th scope="col">Ad Name</th>
                                  <th scope="col">Status</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $show_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <th scope="row"><?php echo e($loop->iteration); ?></th>
                                  <td><?php echo e($value->title); ?></td>
                                  <td>
                                      <?php if($value->status==0): ?> Pending <?php endif; ?>
                                      <?php if($value->status==1): ?> Accept <?php endif; ?>
                                      <?php if($value->status==2): ?> Canceled <?php endif; ?>
                                  </td>
                                  
                                </tr>
                                <!-- item end -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/customer/allreports.blade.php ENDPATH**/ ?>