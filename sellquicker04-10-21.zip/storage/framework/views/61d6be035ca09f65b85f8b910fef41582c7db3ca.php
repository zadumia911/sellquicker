<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('content'); ?>
 <div class="search-and-category">
 	<div class="container">
 		<div class="row">
 			<div class="col-sm-12">
 				<div class="search-text">
 					<h5>The largest marketplace in Bangladesh!</h5>
 					<p>Buy and sell everything from used cars to mobile phones and computers, or search for property, jobs and more in Bangladesh!</p>
 				</div>
 				<form  action="<?php echo e(url('home-search')); ?>" method="get" class="main-search-box">
				<?php echo csrf_field(); ?>
					<input type="text" name="keyword" placeholder="Search keyword" class="search-keyword" required="">
					<button>search</button>
			  </form>
			  <div class="category-section">
	 			<?php $__currentLoopData = $homecategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <a href="<?php echo e(url('category/'.$category->slug)); ?>">
					<div class="single-category">
						<ul>
							<li><img src="<?php echo e(asset($category->image)); ?>"></li>
							<li><a href="<?php echo e(url('category/'.$category->slug)); ?>"><?php echo e($category->name); ?> 
	                          </a></li>
						</ul>
					</div>
				</a>
			     <!-- single category end -->
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 		</div>
 			</div>
 		</div>
 	</div>
 </div>
 <!-- search and category -->
 <div class="all-category">
 	<div class="container">
 		<div class="row">
 			<div class="col-sm-12">
 				<h4>All CATEGORIES</h4>
 			</div>
 		</div>
 		<div class="row">
 			<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 			<div class="col-sm-4">
 				<div class="allcategory-item">
 					<div class="row">
	 					<div class="col-sm-2">
	 						<img src="<?php echo e(asset($value->image)); ?>" alt="">
	 					</div>
	 					<div class="col-sm-10">
	 						<div class="subcategory">
	 							<ul>
	 								<li class="highlight"><a href=""><?php echo e($value->name); ?></a></li>
	 								<?php $__currentLoopData = $value->hsubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	 								<li><a href=""><?php echo e($subcategory->subcategoryName); ?></a></li>
	 								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	 							</ul>
	 						</div>
	 					</div>
	 				</div>
 				</div>
 			</div>
 			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 		</div>
 	</div>
 </div>
<section class="post-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
            	<div class="post-left">
            		<h4>Do you have something to sell?</h4>
            		<p>Post your ad on sellquicker.net/</p>
            		<a href="">post your ad</a>
            	</div>
            </div>
            <div class="col-sm-6">
                <div class="post-right">
                	<img src="<?php echo e(asset('public/frontEnd/images/ads.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp\htdocs\sellquicker\resources\views/frontEnd/index.blade.php ENDPATH**/ ?>