<?php $__env->startSection('title',$breadcrumb->name); ?>
<?php $__env->startSection('content'); ?>
<style>
	.display-block {
	    display: block !important;
	}
</style>
<section class="ads-section">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="banner-top-ad">
					<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/category-ads.gif" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<section class="advertisment">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
			 	<div class="filter-and-search">
					<div class="row">
						<div class="col-sm-6 col-12">
							<div class="location-filter">
							<button href="#" type="button" data-toggle="modal" data-target="#exampleModalLong">
							 <i class="fa fa-map-marker"></i> অবস্থান নির্বাচন করুন
							</button>
							</div>
							<!-- Modal -->
							<div class="modal" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
								  <div class="modal-dialog modal-lg location-modal" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								      	   <div class="row">
									      	   	<div class="col-sm-6">
									      	   		<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
									      		 <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												  <a class="nav-link" id="v-pills-home-tab<?php echo e($division->id); ?>" data-toggle="pill" href="#v-pills-home<?php echo e($division->id); ?>" role="tab" aria-controls="v-pills-home<?php echo e($division->id); ?>" aria-selected="true">
												  	<span><?php echo e($division->name); ?></span> <i class="fa fa-angle-right"></i>
												  </a>
												  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
									      	   	</div>
									      	   	<div class="col-sm-6">
									      	   		<div class="tab-content" id="v-pills-tabContent">
											 <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											  <div class="tab-pane fade " id="v-pills-home<?php echo e($division->id); ?>" role="tabpanel" aria-labelledby="v-pills-home-tab<?php echo e($division->id); ?>">
											  	<p><strong><?php echo e($division->name); ?> -এর মধ্যে একটি স্থানীয় এলাকা নির্বাচন করুন</strong></p>
											  	<a href="" class="all-area"><?php echo e($division->name); ?>-এর সবগুলো</a>
											  	<ul class="modal-second-menu">
											  		<?php $__currentLoopData = $division->districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											  		<li>
													  <a data-toggle="collapse" href="#modal-collapse<?php echo e($district->id); ?>" role="button" aria-expanded="false" aria-controls="modal-collapse">
													    <?php echo e($district->dist_name); ?> <i class="fa fa-angle-down"></i>
													  </a>
													  <div class="collapse-area">
														<div class="collapse " id="modal-collapse<?php echo e($district->id); ?>">
															<div class="tree-menu demo custom-tree" id="tree-menu">
														  <ul>
														  	<?php $__currentLoopData = $district->thanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														  	<li><a href=""><?php echo e($thana->thana_name); ?></a>
											  				<ul>
											  					<?php $__currentLoopData = $thana->unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												  				<li><a href=""><?php echo e($union->union_name); ?></a></li>
												  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											  				</ul>
														  	</li>
														  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														  </ul>
														  </div>
														</div>
													  </div>
													</li>
											  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											  	</ul>
											  </div>
											  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
									      	   	</div>
								      	   </div>
								      </div>
								    </div>
								  </div>
							</div>
						</div>
						<div class="col-sm-6 col-12">
							<div class="location-filter">
							<button type="button" data-toggle="modal" data-target="#exampleModalLong2">
							 <i class="fa fa-tag"></i> <?php if($breadcrumb !=NULL): ?> <?php echo e($breadcrumb->name); ?> <?php else: ?> শ্রেণী নির্বাচন <?php endif; ?>
							</button>
							</div>
							<!-- Modal -->
							<div class="modal" id="exampleModalLong2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
								  <div class="modal-dialog modal-lg location-modal" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								      	   <div class="row">
									      	   	<div class="col-sm-6">
									      	   		<div class="nav flex-column nav-pills category-mmenu" id="v-pills-tab" role="tablist" aria-orientation="vertical">
									      		 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												  <a class="nav-link" id="v-pills-category-tab<?php echo e($category->id); ?>" data-toggle="pill" href="#v-pills-category<?php echo e($category->id); ?>" role="tab" aria-controls="v-pills-category<?php echo e($category->id); ?>" aria-selected="true">
												  	<span><?php echo e($category->name); ?></span> <i class="fa fa-angle-right"></i>
												  </a>
												  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>
									      	   	</div>
									      	   	<div class="col-sm-6">
									      	   		<div class="tab-content" id="v-pills-tabContent">
											 <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											  <div class="tab-pane fade " id="v-pills-category<?php echo e($category->id); ?>" role="tabpanel" aria-labelledby="v-pills-category-tab<?php echo e($category->id); ?>">
											  	<p><strong><?php echo e($category->name); ?> -এর উপ-শ্রেণী নির্বাচন করুন</strong></p>
											  	<a href="<?php echo e(url('category/'.$category->slug)); ?>" class="all-area"><?php echo e($category->name); ?>-এর সবগুলো</a>
											  	<ul class="modal-second-menu">
											  		<?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											  		<li>
													  <a href="<?php echo e(url('category/'.$category->slug.'/'.$subcategory->slug)); ?>">
													    <?php echo e($subcategory->subcategoryName); ?> <i class="fa fa-angle-down"></i>
													  </a>
													</li>
											  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											  	</ul>
											  </div>
											  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
									      	   	</div>
								      	   </div>
								      </div>
								    </div>
								  </div>
							</div>
						</div>
					</div> 
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-12">
				<div class="sidebar">
					<div class="ads-type">
						<p>সদস্যের ধরণ</p>
						<form action="">
							<div class="form-control">
								 <input type="radio" name="filter" value="1"  onchange="this.form.submit()" id="urgent" <?php if($filter==1): ?>checked=""<?php endif; ?>>
								 <label for="urgent">নন মেম্বারশিপ</label> 
							</div>
							<div class="form-control">
								<input type="radio" id="dorstep" name="filter" value="2"  onchange="this.form.submit()" <?php if($filter==2): ?>checked=""<?php endif; ?>>
								<label for="dorstep">মেম্বারশিপ</label> 
							</div>
						</form>
					</div>
					<div class="subcategory">
						<div class=" title ">
							<p>সকল শ্রেণী</p>
						</div>
				         <ul>
				            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				             <?php 
				            	$totalcat = App\Advertisment::where(['subcategory_id'=>$value->id,'status'=>1])->get(); 
				            ?> 
				        	<li><a href="<?php echo e(url('category/'.$breadcrumb->slug.'/'.$value->slug)); ?>"><?php echo e($value->subcategoryName); ?> (<?php echo e($totalcat->count()); ?>)</a></li>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				   		 </ul>
					</div>
					  <div class="locationad-inner">
					  	<div class=" title ">
							<p>অবস্থান</p>
						</div>
						<div id="location-ads" class="location-ads ">
							<ul>
							<?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('/location/'.$division->slug)); ?>"><?php echo e($division->name); ?> <span> <?php $totaldiviads = App\Advertisment::where('division_id',$division->id)->get(); ?> (<?php echo e($totaldiviads->count()); ?>)</span></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
							
					    </div>
					</div>
				</div>
			</div>
			<!-- first col-3 -->
			<div class="col-lg-7 col-md-7 col-sm-12">
				<div class="ad-inner">
					<div class="ad-filter">
						<div class="row">
							<div class="col-lg-12 col-sm-6 col-sm-12">
								<div class="ads-breadcrumb">
								  <ul>
									<li><a href="<?php echo e(url('/')); ?>">হোমপেজ</a></li>
									<li><a class="anchor"><i class="fa fa-angle-right"></i></a></li>
									<li><a class="anchor"><?php echo e($breadcrumb->name); ?></a></li>
								</ul>
								<p><?php echo e($breadcrumb->name); ?> এর জন্য  <?php echo e($advertisments->count()); ?> টি  বিজ্ঞাপন খুঁজে পাওয়া গেছে </p>
								</div>
							</div>
							<!-- col end -->
						</div>
					</div>
				  	<div class="list-product-area">
				  		<div class="row">
				  			<div class="col-sm-12">
				  				<?php $__currentLoopData = $advertisments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  				<div class="list-product <?php if($key==0): ?> big-ads <?php endif; ?>">
					  				<a href="">
					  					<div class="row">
									  		<div class="col-lg-4 col-md-4 col-sm-4 col-4">
									  			<div class="list-ad-image">
									  				<a href="<?php echo e(url('details/'.$value->id.'/'.$value->slug)); ?>">
									  					<?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                             <?php if($value->id==$image->ads_id): ?>
							                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
							                              <?php break; ?>
							                              <?php endif; ?>
							                         	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									  				</a>
									  			</div>
									  		</div>
									  		<div class="col-lg-8 col-md-8 col-sm-8 col-8">
									  			<div class="list-ad-info">
									  				<h5><a href="<?php echo e(url('details/'.$value->id.'/'.$value->slug)); ?>"><?php echo e(substr($value->title,0,50)); ?></a></h5>
									  				<?php
									  					$thana = App\Thana::find($value->thana_id);
									  					$union = App\Union::find($value->union_id);
									  				?>
									  				<p><?php echo e($value->divi_name); ?> <i class="fa fa-angle-right"></i> <?php echo e($value->dist_name); ?> <?php if($thana !=NULL): ?> <i class="fa fa-angle-right"></i> <?php echo e($thana->thana_name); ?> 
									  				<?php endif; ?>
									  				<?php if($union !=NULL): ?> <i class="fa fa-angle-right"></i> <?php echo e($union->union_name); ?> 
									  				<?php endif; ?></p>
									  				<p><?php if($value->membership==2): ?>
									  					<img src="<?php echo e(asset('public/frontEnd/images/shield.png')); ?>" alt="" class="membertag">
									  				 <?php endif; ?><?php echo e($value->catname); ?></p>
									  				<strong><?php echo e($value->price); ?></strong>
									  			</div>
									  		</div>
									  	</div>
					  				</a>
				  				</div>
						  		<!-- list product end -->
						  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  		</div>
				  	</div>
				  	</div>
				</div>
				<div class="cpaginate">
					<?php echo e($advertisments->links()); ?>

				</div>
			</div>
			<!-- first col-6 end -->
			<div class="col-sm-2">
				<div class="mads">
					<a href="">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/hproad1.jpg" alt="">
					</a>
				</div>
				<!-- mads end -->
			</div>
		</div>
		<!-- row end -->
	</div>
</section>
<script>
    $(document).ready(function() {
      $('select').niceSelect();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/frontEnd/layouts/pages/searchads.blade.php ENDPATH**/ ?>