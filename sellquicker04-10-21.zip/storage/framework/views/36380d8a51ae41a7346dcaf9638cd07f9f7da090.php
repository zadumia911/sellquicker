<h3>You have a new massage from your www.kbazar.com.bd</h3>
 <p><b>Name :</b> <?php echo e($cname); ?></p>
 <p><b>Phone :</b> <?php echo e($cphone); ?></p>
 <p><b>Sent Via :</b><?php echo e($cemail); ?></p>
 <p><b>Visitor Says :</b><?php echo e($ctext); ?></p><?php /**PATH /home/mahmudstylexsour/public_html/demo/resources/views/frontEnd/emails/publisher.blade.php ENDPATH**/ ?>