<?php $__env->startSection('title','Cancel Membership'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Customer</a></li>
            <li class="breadcrumb-item active">Cancel Membership</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Cancel Membership</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-actions btn-create">
                All Customer<i class="fas fa-plus"></i>
                </a>
              </div>
            </div>
          </div>
      </div>
        <div class="box-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                       <?php $__currentLoopData = $cancelmembership; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($value->name); ?></td>
                          <td><?php echo e($value->email); ?></td>
                          <td><?php echo e($value->phone); ?></td>
                          <td><img src="<?php echo e(asset($value->image)); ?>" class="backend_image" alt=""></td>
                          <td><?php echo e($value->status==1?"Active":"Inactive"); ?></td>
                          <td>
                            <ul class="action_buttons dropdown">
                              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action Button
                              <span class="caret"></span></button>
                              <ul class="dropdown-menu">
                                  <li>
                                    <form action="<?php echo e(url('superadmin/customer/membership-cancel')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="customer" value="<?php echo e($value->id); ?>">
                                      <button type="submit" onclick="return confirm('Are you sure ? Cancel membership for this customer.')" class="edit_icon"> Cancel Membership</button>
                                    </form>
                                  </li>
                                </ul>
                              </ul>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tfoot>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
          </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/backEnd/customer/cancelmembership.blade.php ENDPATH**/ ?>