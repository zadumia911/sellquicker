<?php $__env->startSection('title','Update category'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Category</a></li>
            <li class="breadcrumb-item active">Update</li>
          </ol>
        </div>
      </div>
    </div>
  </div>


  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Update Category</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/category/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                Manage Category
                </a>
              </div>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="box-content">
            <div class="row">
              <div class="col-sm-2"></div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Update Category</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('editor/category/update')); ?>" method="POST" enctype="multipart/form-data" name="editForm">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" value="<?php echo e($edit_data->id); ?>" name="hidden_id">
                      <div class="card-body">
                        <div class="form-group">
                          <label for="name">Name</label>
                           <input type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->name); ?>" name="name" id="name" placeholder="Ex. Mobile, Electronic">
                           <?php if($errors->has('name')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                              </span>
                            <?php endif; ?>
                        </div>
                        <!-- form group -->
                        <div class="form-group">
                        <label for="image">Image</label>
                            <input type="file" class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('image')); ?>" accept="image/png*" name="image" id="image">
                          <img src="<?php echo e(asset($edit_data->image)); ?>" class="backend_image" alt="">
                             <?php if($errors->has('image')): ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($errors->first('image')); ?></strong>
                              </span>
                              <?php endif; ?>
                      </div>
                        
                        <div class="form-group">
                          <label for="text">Description</label>
                              <textarea type="text" class="summernote form-control <?php echo e($errors->has('text') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('text')); ?>" name="text"><?php echo $edit_data->text; ?></textarea>
                               <?php if($errors->has('text')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('text')); ?></strong>
                                </span>
                                <?php endif; ?>
                        </div>
                        <div class="form-group">
                          <div class="custom-label">
                            <label>Publication Status</label>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                              <label for="active">Active</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                              <label for="inactive">Inactive</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-size">Update</button>
                        </div>
                      </div>
                      <!-- /.card-body -->
                    </form>
                  </div>
              </div>
              <!-- col end -->
              <div class="col-sm-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
    <script type="text/javascript">
      document.forms['editForm'].elements['status'].value="<?php echo e($edit_data->status); ?>"
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/backEnd/category/edit.blade.php ENDPATH**/ ?>