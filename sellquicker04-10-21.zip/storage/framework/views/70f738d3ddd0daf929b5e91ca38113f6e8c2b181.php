<?php $__env->startSection('title','Manage subcategory'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">subcategory</a></li>
            <li class="breadcrumb-item active">Manage</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Create subcategory</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/subcategory/create')); ?>" class="btn btn-primary btn-actions btn-create">
                Create Subcategory
                </a>
              </div>
            </div>
          </div>
      </div>
        <div class="box-content">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="card">
                  <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $show_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($loop->iteration); ?></td>
                          <td><?php echo e($value->subcategoryName); ?></td>
                          <td><?php echo e($value->name); ?></td>
                          <td><?php echo e($value->status==1?"Active":"Inactive"); ?></td>
                          <td><ul class="action_buttons dropdown">
                              <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Action Button
                              <span class="caret"></span></button>
                              <ul class="dropdown-menu">
                                <li>
                                  <?php if($value->status==1): ?>
                                  <form action="<?php echo e(url('editor/subcategory/inactive')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                    <button type="submit" class="thumbs_up" title="unpublished"><i class="fa fa-thumbs-up"></i> Active</button>
                                  </form>
                                  <?php else: ?>
                                    <form action="<?php echo e(url('editor/subcategory/active')); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                      <button type="submit" class="thumbs_down" title="published"><i class="fa fa-thumbs-down"></i> Inactive</button>
                                    </form>
                                  <?php endif; ?>
                                </li>
                                  <li>
                                      <a class="edit_icon" href="<?php echo e(url('editor/subcategory/edit/'.$value->id)); ?>" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                  </li>
                                </ul>
                              </ul>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tfoot>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
          </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/backEnd/subcategory/manage.blade.php ENDPATH**/ ?>