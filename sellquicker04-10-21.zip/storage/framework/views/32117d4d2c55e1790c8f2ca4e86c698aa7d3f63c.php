
<?php $__env->startSection('title','Create Subcategory'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Subcategory</a></li>
            <li class="breadcrumb-item active">Create</li>
          </ol>
        </div>
      </div>
    </div>
  </div>


  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Create Subcategory</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/subcategory/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                Manage Subcategory
                </a>
              </div>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="box-content">
            <div class="row">
              <div class="col-sm-2"></div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Create Subcategory</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('editor/subcategory/save')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="card-body">
                         <div class="form-group">
                              <label>Name</label>
                              <input type="text" name="subcategoryName" class="form-control<?php echo e($errors->has('subcategoryName') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('subcategoryName')); ?>">

                              <?php if($errors->has('subcategoryName')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('subcategoryName')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        <!-- form group -->
                        <div class="form-group">
                              <label>Category</label>
                              <select name="category_id" class="form-control select2 <?php echo e($errors->has('category_id') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('category_id')); ?>">
                                <option value="">===select category===</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>

                              <?php if($errors->has('category_id')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('category_id')); ?></strong>
                              </span>
                              <?php endif; ?>
                         </div>
                        <!-- form group -->
                        <div class="form-group">
                          <div class="custom-label">
                            <label>Publication Status</label>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                              <label for="active">Active</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                              <label for="inactive">Inactive</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-size">Save</button>
                        </div>
                      </div>
                      <!-- /.card-body -->
                    </form>
                  </div>
              </div>
              <!-- col end -->
              <div class="col-sm-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/backEnd/subcategory/create.blade.php ENDPATH**/ ?>