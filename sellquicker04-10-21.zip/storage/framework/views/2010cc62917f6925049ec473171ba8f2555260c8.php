<?php $__env->startSection('title','Details'); ?>
<?php $__env->startSection('content'); ?>
<section class="commondesign">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12">
				<div class="advertisment-details">
				    <div class="row">
				    	<div class="col-sm-12">
							<div class="advertisment-details-header">
								<h5><?php echo e($adsdetails->title); ?></h5>
								<p>For sale by <a href="#"><?php echo e($adsdetails->customerName); ?></a>
									<?php
					  					$thana = App\Thana::find($adsdetails->thana_id);
					  					$union = App\Union::find($adsdetails->union_id);
					  				?>
					  				<?php echo e($adsdetails->division_name); ?> <i class="fa fa-angle-right"></i> <?php echo e($adsdetails->dist_name); ?> <?php if($adsdetails !=NULL): ?> <i class="fa fa-angle-right"></i> <?php echo e($thana->thana_name); ?> 
					  				<?php endif; ?>
					  				<?php if($union !=NULL): ?> <i class="fa fa-angle-right"></i> <?php echo e($union->union_name); ?> 
					  				<?php endif; ?></p>
							</div>
				    	</div>
					    <div class="col-sm-7">
							<!-- details head end-->
							<div class="advertisment-details-body">
								<div class="dslider owl-carousel">
									<?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                               <?php if($adsdetails->id==$image->ads_id): ?>
		                               <div class="dslider-item">
										<img src="<?php echo e(asset($image->image)); ?>" alt="">
										</div>
										<!-- dslider end -->
		                                <?php endif; ?>
		                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</div>
							</div>
							<div class="report-btn">
							    <button data-toggle="modal" data-target="#exampleModal">Report this ad</button>
							</div>
						</div>
						<div class="col-sm-5">
							<div class="row">
								<div class="col-sm-12">
									<ul class="customer-phone">
										<li class="fmobile-hide"><i class="fa fa-phone"></i><a href="tel:<?php echo e($adsdetails->phone); ?>"><?php echo e($adsdetails->phone); ?> <span>বিজ্ঞাপন দাতার ফোন নাম্বার </span></a>
										</li>
										<li class="fmobile-hide"><i class="fa fa-comments"></i> <a href="">চ্যাট করুন </a>
										</li>
										<li><i class="fa fa-clock-o"></i> <a href="">বিজ্ঞাপনের তারিখ  <span><?php echo e($adsdetails->created_at); ?></span></a>
										</li>
										<li><i class="fa fa-user"></i> <a href=""><?php if($adsdetails->membership==1): ?> <i class="fa fa-circle text-success"></i> <?php endif; ?> <?php echo e($adsdetails->customerName); ?> <?php if($adsdetails->membership==1): ?><img src="<?php echo e(asset('public/frontEnd')); ?>/images/shield.png" alt="" width="20"/><?php endif; ?> <span>এই মেম্বারের পেইজ ভিজিট করুন</span></a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-12">
							<div class="dprice">
								<h5>Price:  <?php echo e($adsdetails->price); ?></h5>
							 </div>
							<div class="content">
								<div class="row">
									<div class="col-sm-4">
									    <div class="share-btn desktop">
										    <p><i class="fa fa-share-alt"></i> শেয়ার করুন </p>
                                            <div class="addthis_inline_share_toolbox_wrjo"></div>
                        				</div>
										<div class="product-basic">
											 <ul>
											  	<li>Consition : </li>
											  	<li><?php echo e($adsdetails->version==1?"New":"Used"); ?></li>
											 </ul> 
											 <ul>
											  	<li>Brand : </li>
											  	<li><?php echo e($adsdetails->brand); ?></li>
											 </ul> 
											 <ul>
											  	<li>Model : </li>
											  	<li><?php echo e($adsdetails->model); ?></li>
											 </ul> 
											 <ul>
											  	<li>Edition : </li>
											  	<li><?php echo e($adsdetails->edition); ?></li>
											 </ul>  
											 <ul>
											  	<li>Authencity : </li>
											  	<li><?php echo e($adsdetails->type==1?"Copy":"Original"); ?></li>
											 </ul>  
										</div>
									</div>
								</div>
								<div class="ads-feature">
									<h5>Featured</h5>
									<div class="row">
										<div class="col-sm-8">
											<p><?php echo e($adsdetails->feature); ?></p>
										</div>
									</div>
								</div>
								<div class="ads-description">
									<h5>Description</h5>
									<div class="row">
										<div class="col-sm-8">
											<p><?php echo $adsdetails->description; ?></p>
										</div>
									</div>
								</div>
							</div>
							<div class="share-btn mobile">
								<p><i class="fa fa-share-alt"></i> শেয়ার করুন </p>
        <div class="addthis_inline_share_toolbox_wrjo"></div>
    
							</div>	
						</div>
						
					</div>
				</div>
			</div>
			<!-- col end -->
			<!-- <div class="col-lg-4 col-md-12 col-sm-12">
				<div class="csidebar">
					<div class="mads">
						<a href="">
							<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/google.dad1.png" alt="">
						</a>
					</div>
					<div class="contact-topublisher">
						<h5>Contact Publisher</h5>
						<strong>Name: <?php echo e($adsdetails->customerName); ?></strong>
						<strong>Phone: <?php echo e($adsdetails->customerPhone); ?></strong>

						<form action="<?php echo e(url('message/visitor/to/publisher')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php if($adsdetails->customerEmail): ?>
							<input type="hidden" value="<?php echo e($adsdetails->customerEmail); ?>" name="hiddenEmail">
							<?php else: ?>
							<input type="hidden" value="addressnotfound@kbazar.com.bd" name="hiddenEmail">
							<?php endif; ?>
							<div class="form-group">
								<input type="hidden" name="cname" value="zadu" class="form-control" class="cname" placeholder="Your Name">
							</div>
							<div class="form-group">
								<input type="cemail" class="form-control" name="cemail" placeholder="Your Email">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" name="cphone" placeholder="Your Phone">
							</div>
							<textarea name="ctext" id=""  rows="5" style="width:100%" placeholder="Your Message"></textarea>
							<div class="form-group">
								<button>submit</button>
							</div>
						</form>
					</div>
				</div>
			</div> -->
			<!-- col end -->
		</div>
	</div>
</section>
<section>
    <div class="container-fluid">
    	<div class="row">
        	<div class="col-sm-12">
            	<div class="mobile-chat-phon" id="mobile-chat-phon">
                	<div class="row">
                		<div class="col-6">
                			<div class="m-phone-icon">
                				<a href="tel:<?php echo e($adsdetails->phone); ?>">Call</a>
                			</div>
                		</div>
                		<div class="col-6">
                			<div class="m-chat-icon">
                				<a href="tel:">Chat</a>
                			</div>
                		</div>
                	</div>
            	</div>
        	</div>
    	</div>
    </div>
</section>

<!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"> এই বিজ্ঞাপনটিতে রিপোর্ট করুন </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php
         $customerId=Session::get('customerId');
          $customerInfo=App\Customer::where(['id'=>$customerId])->first();
     ?>
     <?php if($customerId !==NULL): ?>
      <form action="<?php echo e(url('report/ad')); ?>" method="POST">
        <?php echo csrf_field(); ?>
         <input  name="ad_id" type="hidden" value="<?php echo e($adsdetails->id); ?>">
         
          <div class="modal-body report-area">
                <div class="form-group">
                    <textarea type="text" name="adreport" class="form-control" required style="border:1px solid #ddd;" value="রিপোর্ট লিখুন"></textarea>
                </div>
               
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary reportsubbtn"> রিপোর্ট করুন </button>
          </div>
      </form>
      <?php endif; ?>
       <?php if($customerId == NULL ): ?>
       <div class="log-btn">
        <a href="<?php echo e(url('customer/login')); ?>" class="btn btn-primary reportsubbtn"> Please Login </a>
       </div>
       <?php endif; ?>
      
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/layouts/pages/details.blade.php ENDPATH**/ ?>