
<?php $__env->startSection('title','Create Subarea'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Subarea</a></li>
            <li class="breadcrumb-item active">Create</li>
          </ol>
        </div>
      </div>
    </div>
  </div>


  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Create Subarea</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/subarea/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                <i class="fas fa-eye"></i> Manage
                </a>
              </div>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="box-content">
            <div class="row">
              <div class="col-sm-2"></div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Create Subarea</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('editor/subarea/save')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="card-body">
                         <div class="form-group">
                              <label>Subarea Name</label>
                              <input type="text" name="subareaName" class="form-control<?php echo e($errors->has('subareaName') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('subareaName')); ?>">

                              <?php if($errors->has('subareaName')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('subareaName')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        <!-- form group -->
                        <div class="form-group">
                              <label>Area</label>
                              <select name="area_id" class="form-control select2 <?php echo e($errors->has('area_id') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('area_id')); ?>">
                                <option value="">===select area===</option>
                                <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>

                              <?php if($errors->has('area_id')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('area_id')); ?></strong>
                              </span>
                              <?php endif; ?>
                         </div>
                        <!-- form group -->
                        <div class="form-group">
                          <div class="custom-label">
                            <label>Publication Status</label>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                              <label for="active">Active</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                              <label for="inactive">Inactive</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-size">Save</button>
                        </div>
                      </div>
                      <!-- /.card-body -->
                    </form>
                  </div>
              </div>
              <!-- col end -->
              <div class="col-sm-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mahmudstylexsour/public_html/demo/resources/views/backEnd/subarea/create.blade.php ENDPATH**/ ?>