<?php $__env->startSection('title','Customer Register'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
               <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>My Dashboard</p>
                    </div>
                     <?php
                         $customerId = Session::get('customerId');
                         $ifverified=App\Customer::where(['id'=>$customerId])->where('verify',0)->first();
                         $userActiveAds = App\Advertisment::where('customer_id',Session::get('customerId'))->where('status',1)->count();
                         $userInactiveAds = App\Advertisment::where('customer_id',Session::get('customerId'))->where('status',0)->count();
                    ?>
                    <?php if($ifverified): ?>
                        <?php if($ifverified->verify!=1): ?>
                         <div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <form action="<?php echo e(url('customer/auth/0/control-panel/account-verify')); ?>" method="POST" novalidate enctype="multipart/form-data" name="editForm"> <strong>Hello! <?php echo e($ifverified->fullName); ?></strong> your account still not verified you can verify it with your email verify now.
                        	<?php echo csrf_field(); ?>  <button class="ifverifybutton">vefiry</button>
                        	</form>
                          </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="ads-count">
                        <div class="row">
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>">
                                    <div class="box-inner box-bg-1">
                                        <i class="fa fa-diamond"></i>
                                        <p>Total Ads</p>
                                        <p>(<?php echo e($userActiveAds+$userInactiveAds); ?>)</p>
                                    </div>
                                 </a>
                            </div>
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>">
                                    <div class="box-inner box-bg-2">
                                        <i class="fa fa-smile-o"></i>
                                        <p>Active Ads</p>
                                        <p>(<?php echo e($userActiveAds); ?>)</p>
                                    </div>
                                 </a>
                            </div>
                            <div class="col-sm-4">
                                <a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>">
                                    <div class="box-inner box-bg-3">
                                        <i class="fa fa-frown-o"></i>
                                        <p>Inactive Ads</p>
                                        <p>(<?php echo e($userInactiveAds); ?>)</p>
                                    </div>
                                 </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sellquicker\resources\views/frontEnd/customer/dashboard.blade.php ENDPATH**/ ?>