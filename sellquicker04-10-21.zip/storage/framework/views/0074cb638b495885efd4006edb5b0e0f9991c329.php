<?php $__env->startSection('title','Create Pagecategory'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Pagecategory</a></li>
            <li class="breadcrumb-item active">Create</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Create Pagecategory</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/pagecategory/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                Manage Pagecategory
                </a>
              </div>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="box-content">
            <div class="row">
              <div class="col-sm-2"></div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Create pagecategory</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('editor/pagecategory/save')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="card-body">
                         <div class="form-group">
                              <label>Page Name</label>
                              <input type="text" name="pagename" class="form-control<?php echo e($errors->has('pagename') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('pagename')); ?>" placeholder="Ex. terms & condigin">
                              <?php if($errors->has('pagename')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('pagename')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <!-- form group -->
                        <div class="form-group">
                              <label>Parent Menu</label>
                              <select name="menu_id" class="form-control select2 <?php echo e($errors->has('menu_id') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('menu_id')); ?>">
                                <option value="">=== Select Parent Menu ===</option>
                                <option value="1">About Us</option>
                                <option value="2">Others</option>
                              </select>
                              <?php if($errors->has('menu_id')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('menu_id')); ?></strong>
                              </span>
                              <?php endif; ?>
                         </div>
                        <!-- form group -->
                        <div class="form-group">
                          <div class="custom-label">
                            <label>Publication Status</label>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                              <label for="active">Active</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                              <label for="inactive">Inactive</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-size">Save</button>
                        </div>
                      </div>
                      <!-- /.card-body -->
                    </form>
                  </div>
              </div>
              <!-- col end -->
              <div class="col-sm-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp\htdocs\sellquicker\resources\views/backEnd/pagecategory/create.blade.php ENDPATH**/ ?>