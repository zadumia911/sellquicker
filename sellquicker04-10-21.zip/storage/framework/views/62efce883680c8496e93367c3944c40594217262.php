<?php $__env->startSection('title','হোমপেজ'); ?>
<?php $__env->startSection('content'); ?>
<section class="home-banner-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
			    <?php $__currentLoopData = $desktopbanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="home-banner desktop-banner">
					<img src="<?php echo e(asset($value->image)); ?>" alt="">
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			 <?php $__currentLoopData = $mobilebanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="home-banner mobile-banner">
					<img src="<?php echo e(asset($value->image)); ?>" alt="">
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</section>

 <div class="home-search">
 	<div class="container-fluid">
 		<div class="row">
 			<div class="col-sm-12">
 				<form  action="<?php echo e(url('home-search')); ?>" method="get" class="hsearch-box form-row">
				<?php echo csrf_field(); ?>
				<div class="col-sm-6">
				    <div class="icon-input-field">
				        <div class="icon">
				            <img src="<?php echo e(asset('public/frontEnd/')); ?>/images/LOCATION.png" alt="" class="location-icon">
				        </div>
				        <div class="input-field">
				            <select name="location" id="" class="search-select form-control" style="border:1px solid #ddd; height:42px;">
        					<option value="">Location</option>
        					<?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        					  <option value="<?php echo e($district->id); ?>"><?php echo e($district->dist_name); ?></option>
        					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				</select>
				        </div>
				    </div>
				</div>
				<div class="col-sm-6">
				    <div class="icon-input-field">
				        <div class="icon">
				            <img src="<?php echo e(asset('public/frontEnd/')); ?>/images/price-tag.png" alt="" class="price-tag">
				        </div>
				        <div class="input-field">
				           <select name="category" id="" class="search-select form-control" style="border:1px solid #ddd; height:42px;">
        					<option value="">Category</option>
        					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        					<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
        					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				</select>
				        </div>
				    </div>
				</div>
				<div class="col-sm-6">
					<input type="text" name="keyword" placeholder="keyword" class="search-keyword" required="">
				</div>
				<div class="col-sm-6">
					<input type="submit" value="search" class="search-submit">
				</div>
			</form>
 			</div>
 		</div>
 	</div>
 </div>
<section class="category-section">
	<div class="category-inner">
		<div class="container-fluid">
			<div class="row">
				<?php $__currentLoopData = $homecategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-3 col-md-3 col-sm-6 col-6">
					<a href="<?php echo e(url('category/'.$category->slug)); ?>">
						<div class="single-category">
							<ul>
								<li><img src="<?php echo e(asset($category->image)); ?>"></li>
								<li><a href="<?php echo e(url('category/'.$category->slug)); ?>"><?php echo e($category->name); ?> 
		                          </a></li>
							</ul>
						</div>
					</a>
				</div>
				<!-- single category end -->
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="home-top-ads">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/home-top-ads.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- category section end -->
<section class="postsection">
        <div class="container-fluid">
            <div class="row">
                <div class="col-6">
                    <div class="all-ads-button">
                        <a href="<?php echo e(url('all-ads')); ?>">View All Ad</a>
                    </div>
                </div>
                <div class="col-6">
                    <div class="post-ads-button">
                        <a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>">post your ad</a>
                    </div>
                </div>
                <div class="col-sm-3 col-1"></div>
            </div>
        </div>
    </section>
<?php if($news!=NULL): ?>
    <section>
       <div id="myModal" class="modal fade home-page-modal" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              <div class="modal-body">
                  <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <h3><?php echo e($value->title); ?> </h3>
                 <p><?php echo $value->text; ?></p>
                 <script type="text/javascript">
        $(window).on('load',function(){
            $('#myModal').modal('show');
        });
    </script>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
      </div>
   </section>
    
   <?php endif; ?>
 
<script>
    // $(document).ready(function() {
    //   $('select').niceSelect();
    // });
</script>
<script>
//     $(window).scroll(function(e){ 
//       var $el = $('.postsection'); 
//       if ($(this).scrollTop() < 1200){
//         $el.css({'position': 'fixed', 'top': '0px'}); 
//       } 
//     });
// </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/index.blade.php ENDPATH**/ ?>