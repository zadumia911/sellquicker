<?php $__env->startSection('title','Customer Register'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
               <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>My Dashboard</p>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mahmudstylexsour/public_html/demo/resources/views/frontEnd/customer/dashboard.blade.php ENDPATH**/ ?>