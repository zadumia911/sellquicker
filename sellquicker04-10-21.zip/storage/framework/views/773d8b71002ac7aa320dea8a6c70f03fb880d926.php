<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $__env->yieldContent('title',''); ?> - হাতবদল ডট কম - বাংলাদেশের জনপ্রিয় মার্কেটপ্লেস  </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <meta name="description" content="Hatbodol.com is a third party or a medium based website for trading. From which you will find the news of all the people of Bangladesh selling new or old things. This means that through this website you can find out who wants to sell what and who wants to buy what. Many of the well-known people in your city or in your area have advertised for free on hatbodol.com to sell anything new or old, so you can visit their ads on hatbodol.com for free and see if you like. You can buy it by contacting the advertiser. It is good to say that hatbodol.com is providing services at every union level in Bangladesh. Yes, I am telling you that if you want to sell any used or unused new or old that you have, you can advertise for free at hatbodol.com. Then you can understand that it is very simple to trade locally in your area through hatbodol.com. Our team carefully monitors and reviews all ads to ensure that the quality of the ads is in line with our company's policies.">
   <meta name="keywords" content="hatbodol,hatbodol,com,haatbodol,haatbodol.com,htbdl,hathbodol,haatbadal,hathbadal,haatbadak,htbdal,hatbadal,hatbadal,.com,hathbodal,hathbodul, hatbodul,haatbudul,hathdodol,hatbodol,com,kasbabazar.com.bc,kasbabazar.com,kasba, hutbadal,hatbadal,hatbadal.com">
    <?php $__currentLoopData = $faveicon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset($value->image)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- all css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/bootstrap.min.css">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/font-awesome.min.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/feathericon.min.css">
    <!-- feathericon css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/dist/css/toastr.min.css">
    <!-- toastr -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/swiper-menu.css">
    <!-- swiper-menu css -->

    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/theme.css">
    <!-- mtree css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
    <!-- summernote css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/owl.carousel.min.css">
    <!-- owl.carousel.min css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/owl.theme.default.css">
    <!-- owl.theme.default css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/nice-select.css">
    <!-- owl.theme.default css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/style.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/responsive.css">
    <!-- responsive css -->
    <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery-3.4.1.min.js"></script>
    <script data-ad-client="ca-pub-3346835581317070" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script
</head>
<body>
	<div class='gotop'></div>
	<header class="show-nav">
		<div class="header-top ">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <div class="header-top-left">
	                        <div class="main-logo">
	                            <a href="<?php echo e(url('/')); ?>">
                                    <?php $__currentLoopData = $wlogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <img src="<?php echo e(asset($value->image)); ?>" class="desktop-logo" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $dlogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <img src="<?php echo e(asset($value->image)); ?>" class="mobile-logo" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </a>
	                        </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="header-top-right">
                            <div class="main-menu">
                                <ul>
                                    <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
                                    <?php
                                         $customerId=Session::get('customerId');
                                          $customerInfo=App\Customer::where(['id'=>$customerId])->first();
                                    ?>
                                    <?php if($customerId==NULL): ?>
                                    <li><a href="<?php echo e(url('page/about-us')); ?>">About Us</a></li>
                                    <li><a href="<?php echo e(url('page/stay-safe')); ?>" >Stay Safe</a></li>
                                    <li><a href="<?php echo e(url('page/about-membership')); ?>" >About Membership</a></li>
                                    <li><a href="<?php echo e(url('customer/login')); ?>"></i>Login</a></li>
                                    <li><a href="<?php echo e(url('customer/register')); ?>">Register</a></li>
                                    <?php endif; ?>
                                    <?php if($customerId!==NULL): ?>
                                     <li><a href="<?php echo e(url('/customer/0/control-panel/dashboard')); ?>">My Account</a>
                                         <ul class="cat-submenu">
                                           <li><a href="">Inbox</a></li>
                                           <li><a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>">Promote Single Ad</a></li>
                                           <li><a href="<?php echo e(url('customer/0/control-panel/dashboard')); ?>">Manage Account</a></li>
                                           <li><a href="<?php echo e(url('customer/0/control-panel/membership-request')); ?>">My Membership</a></li>
                                           <li><a href="https://www.facebook.com/groups/440866056936777"  target="_blank">Complain & Support</a></li>
                                           <li><a href=" https://play.google.com/store/apps/details?id=hat.com.hatbodol&fbclid=IwAR3fbWVKNIyThEjTl0tVX27kzMGfjM4tyaFJV38039SyGSgvxLUXfVhd70A" target="_blank">Download our app</a></li>
                                         </ul>
                                     </li>
                                      <li><a href="<?php echo e(url('customer/logout')); ?>">Logout</a></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- col end -->
                    <div class="col-sm-3">
                        <ul class="live-chat">
                            <li><a href="<?php echo e(url('/support')); ?>"><img src="<?php echo e(asset('public/frontEnd/images/chat.png')); ?>" alt=""></a></li>
                        </ul>
                        <ul class="header-post-ads">
                            <li class="all-ads"><a href="<?php echo e(url('all-ads')); ?>">all ads</a></li>
                            <li class="post-ads"><a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>">post your ads</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--header top end-->
    </header>
    <!--header end-->
    <section class="mobile-menu ">
        <div class="swipe-menu default-theme">
             <div class="nav-icon">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <nav class="codehim-nav">
                    <ul class="menu-item">
                         <?php if($customerId!==NULL): ?>
                        <li> <a href="<?php echo e(url('/')); ?>">Home</a> </li>
                        <?php
                             $customerId=Session::get('customerId');
                              $customerInfo=App\Customer::where(['id'=>$customerId])->first();
                        ?>
                         <li><a href="">Inbox</a></li>
                         <li><a href="<?php echo e(url('customer/0/control-panel/manage-my-ads')); ?>">Promote Single Ad</a></li>
                         <li><a href="<?php echo e(url('customer/0/control-panel/dashboard')); ?>">Manage Account</a></li>
                         <li><a href="<?php echo e(url('customer/0/control-panel/membership-request')); ?>">My Membership</a></li>
                         <li><a href="https://www.facebook.com/groups/440866056936777">Complain & Support</a></li>
                         <li><a href=" https://play.google.com/store/apps/details?id=hat.com.hatbodol&fbclid=IwAR3fbWVKNIyThEjTl0tVX27kzMGfjM4tyaFJV38039SyGSgvxLUXfVhd70A" target="_blank">Download our app</a></li>
                         <li class="mobile-logout"><a href="<?php echo e(url('customer/logout')); ?>">Logout</a></li>
                        
                        <?php else: ?>
                        <li class="mobile-signin"><a href="<?php echo e(url('customer/register')); ?>">SIGN UP</a></li>
                        <li><a href="<?php echo e(url('/')); ?>" class="active">Home</a></li>
                        <li><a href="<?php echo e(url('page/about-us')); ?>">About Us</a></li>
                        <li><a href="<?php echo e(url('page/stay-safe')); ?>" >Stay Safe</a></li>
                        <li><a href="<?php echo e(url('page/about-membership')); ?>" >About Membership</a></li>
                        <li class="mobile-logout"><a href="<?php echo e(url('customer/login')); ?>"></i>Login</a></li>
                        <?php endif; ?>
                    </ul>
                <!--//Tab-->
            </nav>
        <!--Navigation Icon-->
        	<div class="mobile-logo">
        		<a href="<?php echo e(url('/')); ?>">
                    <?php $__currentLoopData = $dlogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        			<img src="<?php echo e(asset($logo->image)); ?>" alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		</a>
        	</div>
            <ul class="live-chat">
                <li><a href="https://www.facebook.com/groups/440866056936777"><img src="<?php echo e(asset('public/frontEnd/images/chat.png')); ?>" alt=""  target="_blank"></a></li>
            </ul>
        </div>
    </section>
    <div class="mobile-margin-top"></div>
    <!-- mobile menu end -->
    <?php echo $__env->yieldContent('content'); ?>
<footer class="footer">
	<div class="footer-top">
		<div class="container-fluid">
			<div class="row">
                <div class="col-sm-12">
                    <ul>
                        <li class="single-footer-content">
                            <ul>
                                <li><a class="title">Download Apps</a></li>
                                <li><a href=" https://play.google.com/store/apps/details?id=hat.com.hatbodol&fbclid=IwAR3fbWVKNIyThEjTl0tVX27kzMGfjM4tyaFJV38039SyGSgvxLUXfVhd70A" target="_blank">
                                    <img src="<?php echo e(asset('public/frontEnd/')); ?>/images/app.png" alt="">
                                </a></li>
                            </ul>
                        </li>
                        <li class="single-footer-content">
                            <ul>
                                <li><a class="title">Learn More</a></li>
                                <?php $__currentLoopData = $learnmores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('page/'.$value->slug)); ?>" class="<?php if($key==2): ?> fmobile-hide <?php endif; ?> <?php if($key==3): ?> fmobile-hide <?php endif; ?>"><?php echo e($value->pagename); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li class="single-footer-content">
                            <ul>
                                <li><a class="title">Help And Support</a></li>
                                <?php $__currentLoopData = $helpmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('page/'.$value->slug)); ?>" class="<?php if($key=0): ?> fmobile-hide <?php endif; ?>"><?php echo e($value->pagename); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li class="single-footer-content">
                            <ul>
                                <li><a class="title">Social Media</a></li>
                                <li><a href="https://www.facebook.com/হাতবদলকম-118649706647019/" target="_blank">Facebook</a></li>
                                <li><a href="" class="fmobile-hide">Twitter</a></li>
                                <li><a href="https://www.linkedin.com/in/hatbodol/" target="_blank">LinkedIn</a></li>
                                <li><a href="" class="fmobile-hide">Youtube</a></li>
                                <li><a href="" class="fmobile-hide">Instagram</a></li>
                            </ul>
                        </li>
                        <li class="single-footer-content">
                            <ul>
                                <li><a class="title ">About Us</a></li>
                                <?php $__currentLoopData = $aboutmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('page/'.$value->slug)); ?>" class="<?php if($key==0): ?> fmobile-hide <?php endif; ?>"><?php echo e($value->pagename); ?> </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    </ul>
                </div>
			</div>
		</div>
	</div>
	<!-- footer-top end -->
	<div class="footer-bottom">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="copyright">
						<p><?php date('Y') ?> &copy copyright all right reserved hatbodol.com</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- footer-bottom end -->
</footer>
<?php if(Request::segment(1)==''): ?>
<div class="home-space"></div>
<?php endif; ?>
<!-- all jquery script -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/swiper-menu.js"></script>
<!--swiper-menu   js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.ajax.js"></script>
<!-- ajax js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/bootstrap.min.js"></script>
<!-- boostrap css -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/owl.carousel.min.js"></script>
<!--carousel js-->
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<!--waypoints js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.counterup.min.js"></script>
<!--counterup js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.scrollUp.js"></script>
<!--scrollup  js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
  <!-- summernote js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.ntm.js"></script>
<!-- jquery.ntm.js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.nice-select.min.js"></script>
<!-- jquery.nice-select.min.js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/script.js"></script>
<!-- custom script -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/dist/js/toastr.min.js"></script>
<!-- Toastr -->
<?php echo Toastr::message(); ?>

<script>
	$(document).ready(function(){
		$('.addDiv').click(function(){
			document.getElementById('location-ads').classList.add('new-height');
			document.getElementById('addDiv').style="display:none";
			document.getElementById('removeDiv').style="display:block";
		});
		$('.removeDiv').click(function(){
			document.getElementById('location-ads').classList.remove('new-height');
			document.getElementById('removeDiv').style="display:none";
			document.getElementById('addDiv').style="display:block";
		});
	});
</script>
<script type="text/javascript">
        $('#category').change(function(){
        // alert('data');
        var ajaxId = $(this).val();    
        if(ajaxId){
            // alert('in ajaxId');
            $.ajax({
               type:"GET",
               url:"<?php echo e(url('search-category')); ?>?category_id="+ajaxId,
               success:function(res){               
                if(res){
                    $("#subcategory").empty();
                    $("#subcategory").append('<option>Select Subcategory</option>');
                    $.each(res,function(key,value){
                        $("#subcategory").append('<option value="'+key+'">'+value+'</option>');
                    });
               
                }else{
                   $("#subcategory").empty();
                   $("#subcategory").append('<option>Select Subcategory</option>');
                }
               }
            });
        }else{
            $("#subcategory").empty();
            $("#subcategory").append('<option>Select Subcategory</option>');
        }      
       });
        // District Find
        $('#division').change(function(){
            // alert('data');
            var ajaxId = $(this).val();    
            if(ajaxId){
                // alert('in ajaxId');
                $.ajax({
                   type:"GET",
                   url:"<?php echo e(url('search-district')); ?>?division_id="+ajaxId,
                   success:function(res){               
                    if(res){
                        $("#district").empty();
                        $("#district").append('<option>District</option>');
                        $.each(res,function(key,value){
                            $("#district").append('<option value="'+key+'">'+value+'</option>');
                        });
                   
                    }else{
                       $("#district").empty();
                       $("#district").empty().append('<option>District</option>');;
                    }
                   }
                });
            }else{
                $("#district").empty();
                $("#district").append('<option>District</option>');;
            }      
       });
        // Thana Find
        $('#district').change(function(){
            // alert('data');
            var ajaxId = $(this).val();    
            if(ajaxId){
                // alert('in ajaxId');
                $.ajax({
                   type:"GET",
                   url:"<?php echo e(url('search-thana')); ?>?dist_id="+ajaxId,
                   success:function(res){               
                    if(res){
                        $("#thana").empty();
                        $("#thana").append('<option>Select</option>');
                        $.each(res,function(key,value){
                            $("#thana").append('<option value="'+key+'">'+value+'</option>');
                        });
                   
                    }else{
                       $("#thana").empty();
                       $("#thana").empty().append('<option>Select</option>');;
                    }
                   }
                });
            }else{
                $("#thana").empty();
                $("#thana").append('<option>Select</option>');;
            }      
       });
        // Union Find
        $('#thana').change(function(){
            // alert('data');
            var ajaxId = $(this).val();    
            if(ajaxId){
                // alert('in ajaxId');
                $.ajax({
                   type:"GET",
                   url:"<?php echo e(url('search-union')); ?>?thana_id="+ajaxId,
                   success:function(res){               
                    if(res){
                        $("#union").empty();
                        $("#union").append('<option>Select</option>');
                        $.each(res,function(key,value){
                            $("#union").append('<option value="'+key+'">'+value+'</option>');
                        });
                   
                    }else{
                       $("#union").empty();
                       $("#union").empty().append('<option>Select</option>');;
                    }
                   }
                });
            }else{
                $("#union").empty();
                $("#union").append('<option>Select</option>');;
            }      
       });
        // city
 </script>
   <script type="text/javascript">
        $(document).ready(function() {
          $(".btn-success").click(function(){ 
              var html = $(".clone").html();
              $(".increment").after(html);
          });
          $("body").on("click",".btn-danger",function(){ 
              $(this).parents(".control-group").remove();
          });

        });
        // 
    </script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.demo').ntm();
    });
</script>
<script>
    $('.dslider').owlCarousel({
        items: 1,
        loop: true,
        dots: true,
        autoplay: true,
        nav: true,
        mouseDrag: true,
        touchDrag: false,
        autoplayHoverPause: false,
        margin: 0,
        smartSpeed: 1000,
        autoplayTimeout: 5000,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        
    });
    //   slider end
    $('.similerad').owlCarousel({
        items: 2,
        loop: true,
        dots: true,
        autoplay: true,
        nav: true,
        mouseDrag: true,
        touchDrag: false,
        autoplayHoverPause: false,
        margin: 20,
        smartSpeed: 1000,
        autoplayTimeout: 5000,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],  
    });
    //   slider end
</script>

<script>
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("mobile-chat-phon").style.bottom = "0";
  } else {
    document.getElementById("mobile-chat-phon").style.bottom = "-50px";
  }
  prevScrollpos = currentScrollPos;
}

</script>



<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5edb90ac2b31b3f0"></script>

</body>
</html><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/layouts/master.blade.php ENDPATH**/ ?>