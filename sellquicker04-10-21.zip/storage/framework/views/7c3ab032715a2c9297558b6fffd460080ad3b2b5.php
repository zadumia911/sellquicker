<?php $__env->startSection('title','Update Thana'); ?>
<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h5 class="m-0 text-dark">Welcome !! <?php echo e(auth::user()->name); ?></h5>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="#">Thana</a></li>
            <li class="breadcrumb-item active">Update</li>
          </ol>
        </div>
      </div>
    </div>
  </div>


  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
          <div class="col-sm-12">
            <div class="manage-button">
              <div class="body-title">
                <h5>Update Thana</h5>
              </div>
              <div class="quick-button">
                <a href="<?php echo e(url('editor/thana/manage')); ?>" class="btn btn-primary btn-actions btn-create">
                Manage
                </a>
              </div>
            </div>
          </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="box-content">
            <div class="row">
              <div class="col-sm-2"></div>
              <div class="col-lg-8 col-md-8 col-sm-8">
                  <div class="card card-primary">
                    <div class="card-header">
                      <h3 class="card-title">Update Thana</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('editor/thana/update')); ?>" method="POST" enctype="multipart/form-data" name="editForm">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" value="<?php echo e($edit_data->id); ?>" name="hidden_id">
                      <div class="card-body">
                        <div class="form-group">
                            <label>Thana Name</label>
                            <input type="text" name="thana_name" class="form-control<?php echo e($errors->has('thana_name') ? ' is-invalid' : ''); ?>" value="<?php echo e($edit_data->thana_name); ?>">
                            <?php if($errors->has('thana_name')): ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('thana_name')); ?></strong>
                            </span>
                            <?php endif; ?>
                         </div>
                        <!-- form group -->
                        <div class="form-group">
                              <label>District</label>
                              <select name="dist_id" class="form-control<?php echo e($errors->has('dist_id') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('dist_id')); ?>">
                                <option value="">Select</option>
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->dist_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>

                              <?php if($errors->has('dist_id')): ?>
                              <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('dist_id')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        <!-- form group -->
                        <div class="form-group">
                          <div class="custom-label">
                            <label>Publication Status</label>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" id="active" name="status" value="1">
                              <label for="active">Active</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                          <div class="box-body pub-stat display-inline">
                              <input class="form-control<?php echo e($errors->has('status') ? ' is-invalid' : ''); ?>" type="radio" name="status" value="0" id="inactive">
                              <label for="inactive">Inactive</label>
                              <?php if($errors->has('status')): ?>
                              <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('status')); ?></strong>
                              </span>
                              <?php endif; ?>
                          </div>
                        </div>
                        <!-- /.form-group -->
                        <div class="form-group">
                          <button type="submit" class="btn btn-primary btn-size">Update</button>
                        </div>
                      </div>
                      <!-- /.card-body -->
                    </form>
                  </div>
              </div>
              <!-- col end -->
              <div class="col-sm-2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
    <script type="text/javascript">
      document.forms['editForm'].elements['dist_id'].value="<?php echo e($edit_data->district_id); ?>"
      document.forms['editForm'].elements['status'].value="<?php echo e($edit_data->status); ?>"
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp2\htdocs\hatbadal\resources\views/backEnd/thana/edit.blade.php ENDPATH**/ ?>