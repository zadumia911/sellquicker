
<?php $__env->startSection('title','How to quick sell'); ?>
<?php $__env->startSection('content'); ?>
<section class="section-padding customer-bg">
	<div class="container">
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-lg-12 col-md-12 col-sm-12">
				<h3><?php echo e($value->title); ?></h3>
				<div class="ccontent">
					<?php echo $value->text; ?>

				</div>
			</div>
			<!-- col end -->
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<strong>No Content Found</strong>
			<?php endif; ?>
		</div>
	</div>
</section>
<!-- category section end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hatbodol/public_html/resources/views/frontEnd/layouts/pages/footerpage.blade.php ENDPATH**/ ?>