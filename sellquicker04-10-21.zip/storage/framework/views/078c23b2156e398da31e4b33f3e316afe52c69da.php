<?php $__env->startSection('title','Manage My Ads'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-12 sm-hide">
               <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-12">
                <div class="customer-body">
                    <div class="title">
                        <p>My Advertisment</p>
                    </div>
                    <div class="cbmain-content">
                        <div class="ads-table">
                          <div class="ads-new">
                            <a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>">New Ads Post</a>
                          </div>
                          <table class="table table-bordered table-responsive">
                              <thead>
                                <tr>
                                  <th scope="col">Sl No.</th>
                                  <th scope="col">Title</th>
                                  <th scope="col">Category</th>
                                  <th scope="col">Divistion</th>
                                  <th scope="col">Zila</th>
                                  <th scope="col">Image</th>
                                  <th scope="col">Action</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php $__currentLoopData = $manageads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <th scope="row"><?php echo e($loop->iteration); ?></th>
                                  <td><?php echo e($value->title); ?></td>
                                  <td><?php echo e($value->name); ?> <i class="fa fa-long-arrow-right"></i> <?php echo e($value->subcategoryName); ?></td>
                                  <td><?php echo e($value->division_name); ?></td>
                                  <td><?php echo e($value->dist_name); ?></td>
                                  <td>
                                  <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="imagegroup">
                                    <?php if($value->id== $image->ads_id): ?> <img src="<?php echo e(asset($image->image)); ?>" class="smallimage" alt="" class="small_image">
                                    <?php break; ?>
                                     <?php endif; ?>
                                  </div>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </td>
                                  <td>
                                    <ul class="action_btn">
                                      <li class="edit-btn"><a href="<?php echo e(url('customer/0/control-panel/'.$value->id.'/post-edit-ads')); ?>"><i class="fa fa-edit"></i> Edit</a></li>
                                      <li class="delete-btn"><a href="<?php echo e(url('customer/'.$value->slug.'/0/control-panel/'.$value->id.'/post-delete-ads')); ?>" onclick="confirm('Are you sure delete?')"><i class="fa fa-trash"></i> Delete</a>
                                      </li>
                                      <li class="adsmakepremium"><a href="<?php echo e(url('customer/0/control-panel/ads-make-premium')); ?>" onclick="event.preventDefault();document.getElementById('ads-premium').submit();"> <form id="ads-premium" action="<?php echo e(url('customer/0/control-panel/ads-make-premium')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="hidden_id" value="<?php echo e($value->id); ?>">
                                        <input type="submit" value=" Make Premium">
                                     </form><?php if($value->premium==2): ?> Pending Premium <?php else: ?> Make Premium <?php endif; ?></a></li>
                                  </ul>
                                </td>
                                </tr>
                                <!-- item end -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- col end -->
            <div class="col-lg-3 col-md-3 col-sm-12 lg-hide sm-show">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/websolut/public_html/hatbodol/resources/views/frontEnd/customer/myads.blade.php ENDPATH**/ ?>