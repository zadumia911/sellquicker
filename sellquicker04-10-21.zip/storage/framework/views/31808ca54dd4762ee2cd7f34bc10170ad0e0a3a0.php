<?php $__env->startSection('title','Sign In'); ?>
<?php $__env->startSection('content'); ?>
<section class="section-padding commonpanel">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0"></div>
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="commonpanelform">
          <h5 class="title">Sign In</h5>
            <form action="<?php echo e(url('/customer/login')); ?>" method="POST">
              <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="text" class="form-control <?php echo e($errors->has('phoneOremail')? 'is-invalid' : ''); ?>" placeholder="Phone Or Email" name="phoneOremail" value="<?php echo e(old('phoneOremail')); ?>">
                  <?php if($errors->has('phoneOremail')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('phoneOremail')); ?></strong>
                    </span>
                  <?php endif; ?>
                 </div>
                <!-- form group -->
                <div class="form-group">
                  <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="Your Password" name="password"  value="<?php echo e(old('password')); ?>" >
                   <?php if($errors->has('password')): ?>
                  <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                  </span>
                  <?php endif; ?>
                </div>
                <!-- form group -->
                <div class="form-group">
                  <div class="stayandforgate">
                     <div class="ls-checkbox auth">
                      <label class="cat-chechbox"><p>remember me</p>
                        <input type="checkbox" value="1">
                        <span class="checkmark"></span>
                      </label>
                     </div>
                     <div class="forgatepassowre">
                        <a href="<?php echo e(url('customer/forget/password')); ?>">forgate passowrd</a>
                     </div>
                  </div>
                </div>
                <div class="form-group">
                  <button>Login</button>
                </div>
                <!-- form group -->
                <div class="form-group newaccount">
                    <p>If you don’t have account?<a href="<?php echo e(url('customer/register')); ?>"> Create An Account</a></p>
                </div>
            </form>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3"></div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Web Development\xampp\htdocs\sellquicker\resources\views/frontEnd/customer/login.blade.php ENDPATH**/ ?>