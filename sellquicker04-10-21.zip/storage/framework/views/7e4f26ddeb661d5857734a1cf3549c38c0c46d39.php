<?php $__env->startSection('title','All Ads'); ?>
<?php $__env->startSection('content'); ?>
<section class="advertisment">
	<div class="container">
		<div class="row">
			<div class="col-lg-9 col-md-7 col-sm-12">
				<div class="ad-inner">
					<div class="row">
						<?php $__currentLoopData = $advertisments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-lg-4 col-md-6 col-sm-6">
								<div class="single-ads">
									<div class="ads-image">
										<a href="<?php echo e(url('details/'.$value->id)); ?>">
											 <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                             <?php if($value->id==$image->ads_id): ?>
					                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
					                              <?php break; ?>
					                              <?php endif; ?>
					                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</a>
									</div>
									<div class="ads-content">
										<ul class="catandloc">
											<li class="cat"><a href=""><i class="fa fa-circle-o"></i><?php echo e($value->catname); ?></a></li>
											<li class="loc"><a href=""><i class="fa fa-map-marker"></i><?php echo e($value->subareaName); ?></a></li>
										</ul>
										<div class="title">
											<a href="<?php echo e(url('details/'.$value->id)); ?>"><?php echo e(substr($value->title,0,30)); ?>..</a>
										</div>
										<ul class="price-wishlist">
											<li class="price"><?php echo e($value->price); ?></li>
											<?php if($value->membership): ?>
											<li class="wishlist"><a href="wishlist">Premium</a></li>
											<?php endif; ?>
										</ul>
									</div>
								</div>
							</div>
							<!-- single ads end -->
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<!-- first col-9 end -->
			<div class="col-lg-3 col-md-5 col-sm-12">
				<div class="mads">
					<a href="">
						<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/hproad1.jpg" alt="">
					</a>
				</div>
				<!-- mads end -->
				<div class="locationad-inner">
					<div id="location-ads" class="location-ads ">
						<ul>
							<?php $__currentLoopData = $subareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('/location/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->subareaName); ?> <span> <?php $totalsubarea = App\Advertisment::where('subarea_id',$value->id)->get(); ?> (<?php echo e($totalsubarea->count()); ?>)</span></a></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						
				    </div>
					<!-- <button type="button" id="addDiv" class="addDiv"><i class="fa fa-plus"></i> Show All</button>
					<button type="button" id="removeDiv" class="removeDiv"><i class="fa fa-minus"></i> Less</button> -->
				</div>
			</div>
			<!-- first col-3 -->
		</div>
		<!-- row end -->
	</div>
</section>
<!-- advertisment end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/frontEnd/layouts/pages/allads.blade.php ENDPATH**/ ?>