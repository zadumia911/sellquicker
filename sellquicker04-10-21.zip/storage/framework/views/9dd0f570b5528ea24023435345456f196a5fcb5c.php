<?php $__env->startSection('title','Edit Ads'); ?>
<?php $__env->startSection('content'); ?>
<section class="customer-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
                <?php echo $__env->make('frontEnd.customer.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- col end -->
            <div class="col-lg-9 col-md-9 col-sm-9">
                <div class="customer-body">
                    <div class="title">
                        <p>Edit Ads</p>
                    </div>
                    <div class="cbmain-content">
                        <form action="<?php echo e(url('/customer/ads/published/update')); ?>" method="POST" novalidate enctype="multipart/form-data" name="editForm">
                        	<?php echo csrf_field(); ?>
                        	<input type="hidden" value="<?php echo e($customerId = Session::get('customerId')); ?>" name="customer">
                              <input type="hidden" value="<?php echo e($edit_data->id); ?>" name="hidden_id">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="category">Category <span>*</span></label>
                                      <select  name="category" id="category" class="form-control <?php echo e($errors->has('category')? 'is-invalid' : ''); ?>" required>
                                            <option value="">===Select Category===</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                             <?php if($errors->has('category')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('category')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                        </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="subcategory">Subcategory <span>*</span></label>
                                      <select  name="subcategory" class="form-control <?php echo e($errors->has('subcategory')? 'is-invalid' : ''); ?>" id="subcategory" required>
                                       	 <option value="">Select Subcategory</option>
                                         <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($value->id); ?>"><?php echo e($value->subcategoryName); ?></option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                          <?php if($errors->has('subcategory')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('subcategory')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                  	   </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="area" >Divistion/Zila <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('area') ? ' is-invalid' : ''); ?>" name="area" id="area" required="required">
                                          <option value="">Location</option>
                                               <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                                      	<option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>

			                                      	</option>
			                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                          <?php if($errors->has('area')): ?>
			                                    <span class="invalid-feedback" role="alert">
			                                      <strong><?php echo e($errors->first('area')); ?></strong>
			                                    </span>
			                                    <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="subarea" >Thana/Zila <span>*</span></label>
                                     <div class="form-group">
                                      <select class="form-control<?php echo e($errors->has('subarea')? 'is-invalid' : ''); ?>" name="subarea" id="subarea" required="required">
                                      	<option value="">Sub Area</option>
                                        <?php $__currentLoopData = $subarea; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($value->id); ?>"><?php echo e($value->subareaName); ?>

                                          </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($errors->has('subarea')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('subarea')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                 	  </select>
                                 </div>
                                 <!--form-group end-->
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="version" >Version <span>*</span></label>
                                      <select class="form-control<?php echo e($errors->has('version') ? ' is-invalid' : ''); ?>" name="version" value="<?php echo e($edit_data->version); ?>" id="version" required="required">
                                          <option value="">Select Version</option>
                                               
                                                <option value="1">Used
                                                <option value="2">New
                                                </option>

                                               <?php if($errors->has('version')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('version')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="type" >Type <span>(optional)</span></label>
                                      <select class="form-control<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>" name="type" value="<?php echo e($edit_data->type); ?>" id="type">
                                          <option value="">Select Type</option>
                                                <option value="1">Original
                                                <option value="2">Copy
                                                </option>
                                      </select>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <label for="title">Ads Title <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('title')? 'is-invalid' : ''); ?>" id="title" placeholder="Ads Title" name="title" value="<?php echo e($edit_data->title); ?>" required>

                                      <?php if($errors->has('title')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group custom-textarea">
                                      <label for="description">Ads Description <span>*</span></label>
                                      <textarea id="description" class="<?php echo e($errors->has('description')? 'is-invalid' : ''); ?>" name="description"><?php echo $edit_data->description; ?></textarea>
                                      <?php if($errors->has('description')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('description')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="phone">Phone Numbers <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('phone')? 'is-invalid' : ''); ?>" id="phone" placeholder="phone numbers" maxlength="25" name="phone" value="<?php echo e($edit_data->phone); ?>" required>

                                      <?php if($errors->has('phone')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('phone')); ?></strong>
                                          </span>
                                          <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="email">Email Address <span>(optional)</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('email')? 'is-invalid' : ''); ?>" id="email" placeholder="Email numbers" maxlength="25" name="email" value="<?php echo e($edit_data->email); ?>">
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->

                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <div class="form-group">
                                      <label for="price">Price <span>*</span></label>
                                      <input type="text" class="form-control<?php echo e($errors->has('price')? 'is-invalid' : ''); ?>" id="price" placeholder="25000" maxlength="25" name="price" value="<?php echo e($edit_data->price); ?>" required>

                                      <?php if($errors->has('price')): ?>
                                          <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('price')); ?></strong>
                                          </span>
                                        <?php endif; ?>
                                    </div>
                                    <!-- form group -->
                                </div>
                                <!-- col end -->
                                
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                  <div class="form-group">
                                    <label for="image">Product Picture<span>*</span></label>

                                      <div class="clone hide" style="display: none;">
                                        <div class="control-group input-group" style="margin-top:10px">
                                          <input type="file" name="image[]" class="form-control">
                                          <div class="input-group-btn"> 
                                            <button class="btn btn-danger" type="button"><i class="fa fa-trash"></i></button>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="input-group control-group increment" >
                                        <input type="file" name="image[]" class="form-control">
                                        <div class="input-group-btn"> 
                                          <button class="btn btn-success" type="button"><i class="fa fa-plus"></i></button>
                                        </div>
                                      </div>
                                       <?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php if($edit_data->id==$image->ads_id): ?> 
                                          <div class="edit-img">
                                            <input type="hidden" class="form-control" value="<?php echo e($image->id); ?>" name="hidden_img">
                                           <img src="<?php echo e(asset($image->image)); ?>" class="editimage" alt="">
                                            <a href="<?php echo e(url('customer/ads/image/delete/'.$image->id)); ?>" class="btn btn-danger">Delete</a>
                                          </div>
                                         <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($errors->has('image')): ?>
                                    <span class="invalid-feedback" role="alert">
                                      <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                  </div>
                                </div>
                                <!-- col end -->
                                <div class="col-lg-12 col-md-12 col-sm-12">
                                    <div class="form-group">
                                      <button class="cbutton">Update</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- col end -->
        </div>
    </div>
</section>
  <script type="text/javascript">
   document.forms['editForm'].elements['category'].value="<?php echo e($edit_data->category_id); ?>"
   document.forms['editForm'].elements['subcategory'].value="<?php echo e($edit_data->subcategory_id); ?>"
   document.forms['editForm'].elements['area'].value="<?php echo e($edit_data->area_id); ?>",
   document.forms['editForm'].elements['subarea'].value="<?php echo e($edit_data->subarea_id); ?>"
   document.forms['editForm'].elements['version'].value="<?php echo e($edit_data->version); ?>"
   document.forms['editForm'].elements['type'].value="<?php echo e($edit_data->type); ?>"
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazar\resources\views/frontEnd/customer/editads.blade.php ENDPATH**/ ?>