<?php $__env->startSection('title','Details'); ?>
<?php $__env->startSection('content'); ?>
<section class="commondesign">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-12 col-sm-12">
				<div class="advertisment-details">
					<div class="advertisment-details-header">
						<h5><?php echo e($adsdetails->title); ?></h5>
						<p>For sale by <a href="#"><?php echo e($adsdetails->customerName); ?></a> <?php echo e($adsdetails->updated_at); ?>  <?php echo e($adsdetails->areaname); ?> , <?php echo e($adsdetails->subareaName); ?></p>
					</div>
					<!-- details head end-->
					<div class="advertisment-details-body">
						<div class="dslider owl-carousel">
							<?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($adsdetails->id==$image->ads_id): ?>
                               <div class="dslider-item">
								<img src="<?php echo e(asset($image->image)); ?>" alt="">
								</div>
								<!-- dslider end -->
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>
						<div class="cphone">
							<a href="tel:<?php echo e($adsdetails->phone); ?>"> Mobile: <?php echo e($adsdetails->phone); ?> </a>
						</div>
						<div class="dprice">
							<h5>Price:  <?php echo e($adsdetails->price); ?></h5>
						</div>
						<div class="content">
							<p> <?php echo e($adsdetails->title); ?></p>
							 <?php echo $adsdetails->description; ?>

						</div>
					</div>
				</div>
				<div class="similer-ad">
					<h4>Related Advertisment</h4>
					<div class="similerad owl-carousel common-snav">
						<?php $__currentLoopData = $relatedads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="single-ads">
							<div class="ads-image">
								<a href="<?php echo e(url('details/'.$value->id)); ?>">
									<?php $__currentLoopData = $adsimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                             <?php if($value->id==$image->ads_id): ?>
		                             <img src="<?php echo e(asset($image->image)); ?>" alt="">
		                              <?php break; ?>
		                              <?php endif; ?>
		                         	 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</a>
							</div>
							<div class="ads-content">
								<ul class="catandloc">
									<li class="cat"><a href=""><i class="fa fa-circle-o"></i><?php echo e($value->catname); ?></a></li>
									<li class="loc"><a href=""><i class="fa fa-map-marker"></i><?php echo e($value->subareaName); ?></a></li>
								</ul>
								<div class="title">
									<a href="<?php echo e(url('details/'.$value->id)); ?>"><?php echo e(substr($value->title,0,50)); ?>..</a>
								</div>
								<ul class="price-wishlist">
									<li class="price"><?php echo e($value->price); ?></li>
									<?php if($value->membership): ?>
									<li class="wishlist"><a href="wishlist">Premium</a></li>
									<?php endif; ?>
								</ul>
							</div>
						</div>
					<!-- single ads end -->
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<!-- similer ads end -->
					<div class="usefull-info">
						<h5>Usefull Information</h5>
						<p>১. বিক্রেতার সাথে দেখা করে পণ্য ভালোভাবে দেখে কিনুন । </p>
						<p>২. পণ্য কেনার সময় বিক্রেতার NID এর ফটোকপি , স্বাক্ষর ও টিকানা দেখে নিন । </p>
						<p>৩. চুরির পণ্য কেনার কিনা থেকে বিরত থাকুন । বিকাশ বা অনযকোন মাধ্যমে আগেই কোনো লেনদেন করবেননা । </p>
						<p>৪. ক্রেতা ও বিক্রেতার সাথে এই সাইটের মালিকের অর্থ লেনদেন , পণ্যর ওয়্যারেন্টি-গ্যারান্টি , পণ্য পরিবহন ইত্যাদি কোন বিষয়ে সংশ্লিষ্টতা নেই ।</p>
					</div>
				</div>
			</div>
			<!-- col end -->
			<div class="col-lg-4 col-md-12 col-sm-12">
				<div class="csidebar">
					<div class="mads">
						<a href="">
							<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/google.dad1.png" alt="">
						</a>
					</div>
					<!-- mads end -->
					<div class="contact-topublisher">
						<h5>Contact Publisher</h5>
						<strong>Name: <?php echo e($adsdetails->customerName); ?></strong>
						<strong>Phone: <?php echo e($adsdetails->customerPhone); ?></strong>

						<form action="<?php echo e(url('message/visitor/to/publisher')); ?>" method="POST">
							<?php echo csrf_field(); ?>
							<?php if($adsdetails->customerEmail): ?>
							<input type="hidden" value="<?php echo e($adsdetails->customerEmail); ?>" name="hiddenEmail">
							<?php else: ?>
							<input type="hidden" value="addressnotfound@kbazar.com.bd" name="hiddenEmail">
							<?php endif; ?>
							<div class="form-group">
								<input type="hidden" name="cname" value="zadu" class="form-control" class="cname" placeholder="Your Name">
							</div>
							<div class="form-group">
								<input type="cemail" class="form-control" name="cemail" placeholder="Your Email">
							</div>
							<div class="form-group">
								<input type="text" class="form-control" name="cphone" placeholder="Your Phone">
							</div>
							<textarea name="ctext" id=""  rows="5" style="width:100%" placeholder="Your Message"></textarea>
							<div class="form-group">
								<button>submit</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			<!-- col end -->
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mahmudstylexsour/public_html/demo/resources/views/frontEnd/layouts/pages/details.blade.php ENDPATH**/ ?>