<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Kbazar.com.bd :: <?php echo $__env->yieldContent('title','Home'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <?php $__currentLoopData = $faveicon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset($value->image)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- all css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/bootstrap.min.css">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/font-awesome.min.css">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/feathericon.min.css">
    <!-- feathericon css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/dist/css/toastr.min.css">
    <!-- toastr -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/swiper-menu.css">
    <!-- swiper-menu css -->

    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/theme.css">
    <!-- mtree css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css" rel="stylesheet">
    <!-- summernote css -->

    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/owl.carousel.min.css">
    <!-- owl.carousel.min css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/owl.theme.default.css">
    <!-- owl.theme.default css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/style.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('public/frontEnd/')); ?>/css/responsive.css">
    <!-- responsive css -->
    <script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery-3.4.1.min.js"></script>
</head>
<body>
     <div class="notverified">
             <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <?php
                             $customerId = Session::get('customerId');
                             $ifverified=App\Customer::where(['id'=>$customerId])->first();
                        ?>
                        <p>
                            <?php if($ifverified): ?>
                                <?php if($ifverified->verify!=1): ?>
                                 <div class="alert alert-danger alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Hello! <?php echo e($ifverified->fullName); ?></strong> Your phone number is not verified. <a href="<?php echo e(url('customer/verify')); ?>" class="ifverifybutton">vefiry</a>
                                  </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
	<div class='gotop'></div>
	<header>
		<div id="stickynav" class="header-top ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12 col-sm-12">
                        <div class="header-top-left">
	                        <div class="main-logo">
	                            <a href="<?php echo e(url('/')); ?>">
                                    <?php $__currentLoopData = $wlogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                                <img src="<?php echo e(asset($value->image)); ?>" alt="">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </a>
	                        </div>
                            <div class="mainmenu">
                                <ul>
                                    <li><a href="<?php echo e(url('/all/ads')); ?>">All Ads</a></li>
                                    <li><a href="<?php echo e(url('/premium/ads')); ?>">Premium Ads</a></li>
                                    <li><a href="<?php echo e(url('/pages/membership/2')); ?>">Membership</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12">
                        <div class="header-top-right">
                            <ul>
                                <?php
                                     $customerId=Session::get('customerId');
                                      $customerInfo=App\Customer::where(['id'=>$customerId])->first();
                                ?>
                                <?php if($customerId==NULL): ?>
                                <li><a href="<?php echo e(url('customer/register')); ?>"><i class="fa fa-user"></i>Register</a></li>
                                <li><a href="<?php echo e(url('customer/login')); ?>"><i class="fa fa-sign-in"></i>Login</a></li>
                                <?php endif; ?>
                                 <?php if($customerId!==NULL): ?>
                                 <li><a class="anchor"><i class="fa fa-user"></i> <?php echo e($customerInfo->name); ?> <i class="fa fa-caret-down"></i></a>
                                    
                                     <ul class="submenu">
                                         <li><a href="<?php echo e(url('/customer/0/control-panel/dashboard')); ?>">My Account</a></li>
                                         <li><a href="<?php echo e(url('customer/logout')); ?>">Logout</a></li>
                                     </ul>
                                 
                                    
                                 </li>
                                <li class="publish-ad"><a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>">publish ad</a></li>
                                 <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--header top end-->
        <div class="main-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="menu-content">
                        	<p>রংপুর বিভাগের সব জেলায় নতুন ও ব্যবহৃত পন্য বিক্রির একমাত্র অনলাইন মার্কেট। ফ্রি একাউন্ট করে ব্যবহৃত ও নতুন পন্য ক্রয়-বিক্রয় করুন।</p>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12">
                        <div class="tgoogle-ads">
                        	<a href=""><img src="<?php echo e(asset('public/frontEnd/')); ?>/images/topbannerads.jpg" alt=""></a>
                        </div>
                    </div>
                </div>
                <!-- row end -->
            </div>
        </div>
        <!--main nav end-->
    </header>
    <!--header end-->
    <section class="mobile-menu ">
        <div class="swipe-menu default-theme">
            <div class="mobile-postad">
            	<a href="<?php echo e(url('customer/0/control-panel/post-new-ads')); ?>">publish ad</a>
            </div>
        <!--Navigation Icon-->
        	<div class="mobile-logo">
        		<a href="<?php echo e(url('/')); ?>">
        			<img src="<?php echo e(asset('public/frontEnd/')); ?>/images/logo.png" alt="">
        		</a>
        	</div>
            <div class="nav-icon">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <nav class="codehim-nav">
                    <ul class="menu-item">
                        <li> <a href="<?php echo e(url('/')); ?>">Home</a> </li>
                        <li class="has-sub ">
                            <span class="dropdown-heading">Help & Support</span> 
	                            <ul>
								<?php $__currentLoopData = $helpmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<li><a href="<?php echo e(url('pages/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->pagename); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							   </ul>
                        </li>
                        <li class="has-sub">
                            <span class="dropdown-heading">About Us</span> 
                            <ul>
								<?php $__currentLoopData = $aboutmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('pages/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->pagename); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
							
                        </li>
                        <li class="has-sub">
                            <span class="dropdown-heading">Social</span> 
                            <ul>
								<li><a href="blog.html" target="_blank">Blog</a></li>
								<li><a href="facebook.com" target="_blank">Facebook</a></li>
								<li><a href="linkedin.com" target="_blank">Linkedin</a></li>
								<li><a href="youtube.com" target="_blank">Youtube</a></li>
							</ul>
                        </li>
                    </ul>
                <!--//Tab-->
            </nav>
        </div>
    </section>
    <!-- mobile menu end -->
    <?php echo $__env->yieldContent('content'); ?>
<footer class="footer">
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-6">
					<div class="footer-about">
						<a href="<?php echo e(url('/')); ?>">
							<?php $__currentLoopData = $dlogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset($value->image)); ?>" alt="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</a>
						<p>Innovative online buy-sell marketplace in Bangladesh.</p>
						<strong>Connect With Us</strong>
						<a href="" class="flikepage"><i class="fa fa-facebook-square"></i> Visit Our Like Page</a>
					</div>
				</div>
				<!-- col-3 end -->
				<div class="col-lg-3 col-md-3 col-sm-6">
					<div class="flink">
						<p class="title">Help & Support</p>
						<ul>
                            <?php $__currentLoopData = $helpmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(url('pages/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->pagename); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6">
					<div class="flink">
						<p class="title">About Us</p>
						<ul>
							<?php $__currentLoopData = $aboutmenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('pages/'.$value->slug.'/'.$value->id)); ?>"><?php echo e($value->pagename); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-6">
					<div class="flink">
						<p class="title">Social</p>
						<ul>
							<li><a href="<?php echo e(url('/')); ?>" target="_blank">Blog</a></li>
							<li><a href="<?php echo e(url('/')); ?>" target="_blank">Facebook</a></li>
							<li><a href="<?php echo e(url('/')); ?>" target="_blank">Linkedin</a></li>
							<li><a href="<?php echo e(url('/')); ?>" target="_blank">Youtube</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- footer-top end -->
	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12">
					<div class="copyright">
						<p>&copy copryright all right reserved kbazar</p>
					</div>
				</div>
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="payment">
                        <img src="<?php echo e(asset('public/frontEnd/')); ?>/images/payment.png" alt="">
                    </div>
                </div>
			</div>
		</div>
	</div>
	<!-- footer-bottom end -->
</footer>
<div class='scrolltop'>
    <div class='scroll icon'><i class="fa fa-angle-up"></i></div>
</div>

<!-- all jquery script -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/swiper-menu.js"></script>
<!--swiper-menu   js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.ajax.js"></script>
<!-- ajax js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/bootstrap.min.js"></script>
<!-- boostrap css -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/owl.carousel.min.js"></script>
<!--carousel js-->
<script src="http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js"></script>
<!--waypoints js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.counterup.min.js"></script>
<!--counterup js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.sticky.js"></script>
<!--sticky nav js-->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.scrollUp.js"></script>
<!--scrollup  js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>
  <!-- summernote js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/jquery.ntm.js"></script>
<!-- jquery.ntm.js -->
<script src="<?php echo e(asset('public/frontEnd/')); ?>/js/script.js"></script>
<!-- custom script -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/dist/js/toastr.min.js"></script>
<!-- Toastr -->
<?php echo Toastr::message(); ?>

<script>
	$(document).ready(function(){
		$('.addDiv').click(function(){
			document.getElementById('location-ads').classList.add('new-height');
			document.getElementById('addDiv').style="display:none";
			document.getElementById('removeDiv').style="display:block";
		});
		$('.removeDiv').click(function(){
			document.getElementById('location-ads').classList.remove('new-height');
			document.getElementById('removeDiv').style="display:none";
			document.getElementById('addDiv').style="display:block";
		});
	});
</script>
<script type="text/javascript">
        $('#category').change(function(){
        // alert('data');
        var ajaxId = $(this).val();    
        if(ajaxId){
            // alert('in ajaxId');
            $.ajax({
               type:"GET",
               url:"<?php echo e(url('search-category')); ?>?category_id="+ajaxId,
               success:function(res){               
                if(res){
                    $("#subcategory").empty();
                    $("#subcategory").append('<option>Select Subcategory</option>');
                    $.each(res,function(key,value){
                        $("#subcategory").append('<option value="'+key+'">'+value+'</option>');
                    });
               
                }else{
                   $("#subcategory").empty();
                   $("#subcategory").append('<option>Select Subcategory</option>');
                }
               }
            });
        }else{
            $("#subcategory").empty();
            $("#subcategory").append('<option>Select Subcategory</option>');
        }      
       });
        // category
        $('#area').change(function(){
        // alert('data');
        var ajaxId = $(this).val();    
        if(ajaxId){
            // alert('in ajaxId');
            $.ajax({
               type:"GET",
               url:"<?php echo e(url('search-area')); ?>?area_id="+ajaxId,
               success:function(res){               
                if(res){
                    $("#subarea").empty();
                    $("#subarea").append('<option>Sub Area</option>');
                    $.each(res,function(key,value){
                        $("#subarea").append('<option value="'+key+'">'+value+'</option>');
                    });
               
                }else{
                   $("#subarea").empty();
                   $("#subarea").empty().append('<option>Sub Area</option>');;
                }
               }
            });
        }else{
            $("#subarea").empty();
            $("#subarea").append('<option>Sub Area</option>');;
        }      
       });
        // city
 </script>
 <script type="text/javascript">
        $(document).ready(function() {
          $(".btn-success").click(function(){ 
              var html = $(".clone").html();
              $(".increment").after(html);
          });
          $("body").on("click",".btn-danger",function(){ 
              $(this).parents(".control-group").remove();
          });

        });
        // 
    </script>
     <script>
      $('#description').summernote({
        placeholder: 'Write Your Content',
        tabsize: 2
      });
    </script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.demo').ntm();
    });
</script>
<script>
    $('.dslider').owlCarousel({
        items: 1,
        loop: true,
        dots: true,
        autoplay: true,
        nav: true,
        mouseDrag: true,
        touchDrag: false,
        autoplayHoverPause: false,
        margin: 0,
        smartSpeed: 1000,
        autoplayTimeout: 5000,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        
    });
    //   slider end
    $('.similerad').owlCarousel({
        items: 2,
        loop: true,
        dots: true,
        autoplay: true,
        nav: true,
        mouseDrag: true,
        touchDrag: false,
        autoplayHoverPause: false,
        margin: 20,
        smartSpeed: 1000,
        autoplayTimeout: 5000,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        
    });
    //   slider end
</script>
</body>
</html><?php /**PATH G:\xampp\htdocs\kbazar\resources\views/frontEnd/layouts/master.blade.php ENDPATH**/ ?>