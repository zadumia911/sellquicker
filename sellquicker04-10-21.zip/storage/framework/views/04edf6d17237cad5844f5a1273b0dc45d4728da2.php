<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Kbazar || <?php echo $__env->yieldContent('title','Dashbaord'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/summernote/summernote-bs4.css">
  <!-- select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/select2/css/select2.min.css">
  <!-- toastr -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <!-- flatpickr -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/dist/css/toastr.min.css">
  <!-- custom css -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/dist/css/custom.css">
  <!-- custome css -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backEnd/')); ?>/plugins/datatables/dataTables.bootstrap4.css">
    <!-- data tab;e -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(url('/')); ?>" target="_blank" class="nav-link"><i class="fas fa-desktop"></i> Visit Website</a>
      </li>
    </ul>

      <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-comments"></i>
          <span class="badge badge-danger navbar-badge">3</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="#" class="dropdown-item">
            <!-- Message Start -->
            <div class="media">
              <div class="media-body">
                <h3 class="dropdown-item-title">
                  Brad Diesel
                  <span class="float-right text-sm text-danger"><i class="fas fa-star"></i></span>
                </h3>
                <p class="text-sm text-muted"><i class="far fa-clock mr-1"></i>4 Hours Ago</p>
              </div>
            </div>
            <!-- Message End -->
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Messages</a>
        </div>
      </li>
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-bell"></i>
          <span class="badge badge-warning navbar-badge">15</span>
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <span class="dropdown-item dropdown-header">15 Notifications</span>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="fas fa-users mr-2"></i> 8 friend requests
            <span class="float-right text-muted text-sm">12 hours</span>
          </a>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
          <i class="fas fa-th-large"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/')); ?>" class="brand-link">
      <span class="brand-text font-weight-light">Kbazar</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="user-image">
          <img src="<?php echo e(asset(auth::user()->image)); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="user-info">
          <a href="#" class="d-block"><?php echo e(auth::user()->name); ?></a>
          <i class="fas fa-circle"></i>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <?php if(Auth::user()->role_id==1): ?>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-users"></i>
              <p>
                Users
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/superadmin/user/create')); ?>" class="nav-link">
                 <i class="far fa-dot-circle  nav-icon"></i> 
                    <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/superadmin/user/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <?php endif; ?>
          <?php if(Auth::user()->role_id==1 || Auth::user()->role_id==2): ?>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="sidebar-icon far fa-chart-bar"></i>
              <p>
                Reports
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('admin/show/ads/request')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Ads Request (<?php echo e($advertisments->count()); ?>)</p>
                </a>
              </li>
              <?php if(Auth::user()->role_id==1): ?>
              <li class="nav-item">
                <a href="<?php echo e(url('/superadmin/customer/membership-request')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Membership Request (<?php echo e($membershiprequest->count()); ?>)</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/superadmin/customer/membership-cancel')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Membership Cancel (<?php echo e($cancelshiprequest->count()); ?>)</p>
                </a>
              </li>
              <?php endif; ?>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fab fa-airbnb"></i>
              <p>
                Logo
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/admin/logo/create')); ?>" class="nav-link">
                 <i class="far fa-dot-circle  nav-icon"></i> 
                    <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/admin/logo/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <?php endif; ?>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-list-ol"></i>
              <p>
                Category
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/category/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/category/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-sliders-h"></i>
              <p>
                Sub Category
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/subcategory/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/subcategory/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-layer-group"></i>
              <p>
                Area
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/area/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/area/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-map-marker-alt"></i>
              <p>
                Sub Area
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/subarea/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/subarea/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
            <i class="fas fa-pager"></i>
              <p>
                Page Category
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/pagecategory/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/pagecategory/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
           <i class="fas fa-tv"></i>
              <p>
                Create Page
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/createpage/create')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Create </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/createpage/manage')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Manage</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="fas fa-user-friends"></i>
              <p>
                Customer
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/editor/customer/list')); ?>" class="nav-link">
                  <i class="far fa-dot-circle nav-icon"></i>
                  <p>Customer List (<?php echo e($advertisments->count()); ?>)</p>
                </a>
              </li>
            </ul>
          </li>
          <!-- nav item end -->
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy;<a href="<?php echo e(url('/')); ?>">Kbazar</a></strong>
    All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item has-treeview">
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="nav-link">
             <i class="fas fa-sign-out-alt"></i>
              <p>Logout</p>
             <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
             </form>
            </a>
          </li>
          <!-- nav item end -->
          <li class="nav-item has-treeview">
            <a href="<?php echo e(url('password/change')); ?>" class="nav-link">
             <i class="fas fa-key"></i>
              <p>Change Password</p>
            </a>
          </li>
          <!-- nav item end -->
      </ul>
    </nav>
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/jqvmap/maps/jquery.vmap.world.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/moment/moment.min.js"></script>
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/datatables/jquery.dataTables.js"></script>
  <!-- DataTables -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/datatables/dataTables.bootstrap4.js"></script>
  <!-- DataTables -->
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<!-- flatpicker -->
<script>
      $(function () {
       flatpickr("#flatpicker", {
        minDate:"today",
       });
      })
  </script>
<script src="<?php echo e(asset('public/backEnd/')); ?>/plugins/select2/js/select2.full.min.js"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('public/backEnd/')); ?>/dist/js/toastr.min.js"></script>
<!-- Toastr -->
<?php echo Toastr::message(); ?>

<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2();
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });

  })
</script>
<script>
  $(function () {
    // Summernote
    $('.summernote').summernote()
  })
</script>
</body>

</html>
<?php /**PATH G:\xampp\htdocs\kbazar\resources\views/backEnd/layouts/master.blade.php ENDPATH**/ ?>