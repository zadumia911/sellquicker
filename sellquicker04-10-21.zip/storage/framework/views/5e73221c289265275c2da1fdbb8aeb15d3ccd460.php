<?php $__env->startSection('title','Customer Register'); ?>
<?php $__env->startSection('content'); ?>
<section class="section-padding commonpanel">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-4"></div>
      <div class="col-lg-5 col-md-5 col-sm-5">
        <div class="commonpanelform">
          <h5 class="title">Create Your Account</h5>
            <form action="<?php echo e(url('customer/register')); ?>" method="POST">
            	<?php echo csrf_field(); ?>
                <div class="form-group">
                  <input type="text" class="form-control  <?php echo e($errors->has('name')? 'is-invalid' : ''); ?>" value="<?php echo e(old('name')); ?>"  id="name" placeholder="Your Name" name="name" >
                  <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <!-- form group -->
                <div class="form-group">
                  <input type="text" class="form-control  <?php echo e($errors->has('phone')? 'is-invalid' : ''); ?>" placeholder="Your Phone" name="phone"   value="<?php echo e(old('phone')); ?>" >
                  <?php if($errors->has('phone')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('phone')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <!-- form group -->
                <div class="form-group">
                  <input type="email" class="form-control  <?php echo e($errors->has('email')? 'is-invalid' : ''); ?>" placeholder="Your Email" name="email"   value="<?php echo e(old('email')); ?>" >
                  <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                  <?php endif; ?>
              	</div>
                <!-- form group -->
                <div class="form-group">
                  <input type="password" class="form-control <?php echo e($errors->has('password')? 'is-invalid' : ''); ?>" placeholder="Your Password" name="password"  value="<?php echo e(old('password')); ?>" >
                  <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <!-- form group -->
                <div class="form-group">
                  <input type="password" name="confirmed" class="form-control  <?php echo e($errors->has('confirmed')? 'is-invalid' : ''); ?>" id="confirmed" placeholder="confirm password" >
                  <?php if($errors->has('confirmed')): ?>
                    <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('confirmed')); ?></strong>
                    </span>
                  <?php endif; ?>
                </div>
                <!-- form group -->
                <div class="form-group" >
                  <div class="stayandforgate" >
                     <div class="common">
                      <label><p>I Am Agree <a href="<?php echo e(url('/termscondition')); ?>">Term and Policy</a></p>
                       
                        </label>
                     </div>
                  </div>
                </div>
                <div class="form-group">
                  <button>Register</button>
                </div>
                <!-- form group -->
                <div class="form-group newaccount">
                    <p>Already have a account?<a href="<?php echo e(url('/customer/login')); ?>"> Log in</a></p>
                </div>
            </form>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3"></div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\kbazarup\resources\views/frontEnd/customer/register.blade.php ENDPATH**/ ?>